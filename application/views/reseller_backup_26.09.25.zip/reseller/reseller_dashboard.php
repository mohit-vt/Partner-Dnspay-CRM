<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper" class="d-flex flex-column min-vh-100">
    <div class="content flex-grow-1">
        <div class="row">

            <!-- Stat Cards -->
            <?php


            $cards = [
                ['label' => 'Inactive Users', 'count' => $inactive_users_count, 'color' => '#FF3131'],
                ['label' => 'Active Agents', 'count' => count($active_agents), 'color' => '#22DD22'],
                ['label' => 'Merchants', 'count' => count($merchants), 'color' => '#0D98BA'],
                ['label' => 'Pre Applications', 'count' => count($pre_applications), 'color' => '#FDDA0D']
            ];
            foreach ($cards as $card) :
                $is_custom_color = str_starts_with($card['color'], '#');
            ?>
                <div class="col-md-2 mb-4">
                    <div class="card text-dark shadow-sm h-100" style="<?= $is_custom_color ? "background-color: {$card['color']};" : "" ?>">
                        <div class="card-body d-flex flex-column justify-content-center align-items-center">
                            <h5 class="card-title text-center" style="color:white;padding-top: 9px;"><?= $card['label'] ?></h5>
                            <p class="card-text display-5 fw-bold text-center" style="color:white;padding-bottom: 5px;"><?= $card['count'] ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
          
          
          	    <!-- Referral Link Card -->
            <?php if (!empty(get_staff()->agent_id)) : ?>
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm border-success h-100">
                        <div class="card-header bg-success text-white text-center fw-semibold">
                            My Referral Link
                        </div>
                        <div class="card-body text-center d-flex flex-column justify-content-center">
                        <?php $referral_link = site_url('pre_application/create?rid=' . urlencode(get_staff()->agent_id)); ?>
                            <input type="text" class="form-control text-center fw-bold mb-2"
                                   value="<?= $referral_link ?>" id="refLink" readonly>
                            <button class="btn btn-sm btn-success" onclick="copyReferral()">Copy Link</button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Chart Section -->
            <div class="col-md-2 mb-4">
                <div class="card shadow-sm">
                    <div class="card-header text-center fw-semibold">
                        Distribution Overview
                    </div>
                    <div class="card-body">
                        <canvas id="distributionChart" style="max-height: 300px;"></canvas>
                    </div>
                </div>
            </div>

            <!-- Growth Chart -->
            <div class="col-md-5 mb-4">
                <div class="card shadow-sm">
                    <div class="card-header text-center fw-semibold">
                        Growth (Last 30 Days)
                    </div>
                    <div class="card-body">
                        <canvas id="growthChart" style="max-height: 300px;"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-body-tertiary text-center text-lg-start">
  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.05);">
  © 2025, Designed and Developed by <strong></strong>
    <a class="text-body" href="https://edatapay.com/">eData Development Group</a>
  </div>
  <!-- Copyright -->
</footer>

    <!-- Sticky Footer -->
    <footer class="bg-light text-center py-3 border-top">
        <div class="container">
            <small class="text-muted"></small>
        </div>
    </footer>
</div>
<?php init_tail(); ?>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
function copyReferral() {
    var copyText = document.getElementById("refLink");
    copyText.select();
    copyText.setSelectionRange(0, 99999);
    document.execCommand("copy");
    //alert("Referral link copied: " + copyText.value);
}
</script>
<script>
    const distributionCtx = document.getElementById('distributionChart').getContext('2d');
    new Chart(distributionCtx, {
        type: 'doughnut',
        data: {
            labels: ['Inactive Users', 'Active Agents', 'Merchants', 'Pre Applications'],
            datasets: [{
                label: 'Distribution',
                data: [<?= $inactive_users_count ?>, <?= count($active_agents) ?>, <?= count($merchants) ?>, <?= count($pre_applications) ?>],
                backgroundColor: ['#FF3131', '#22DD22', '#0D98BA', '#FDDA0D'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });

    const growthCtx = document.getElementById('growthChart').getContext('2d');
    new Chart(growthCtx, {
        type: 'bar',
        data: {
            labels: ['Day 1', 'Day 5', 'Day 10', 'Day 15', 'Day 20', 'Day 25', 'Day 30'],
            datasets: [{
                label: 'New Pre Applications',
                data: [2, 4, 3, 6, 5, 8, 10], // Replace with dynamic data
                backgroundColor: '#007bff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
