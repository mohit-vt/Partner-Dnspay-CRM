<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper" class="d-flex flex-column min-vh-100">
    <div class="content flex-grow-1">
        <div class="container my-4">

            <!-- Header Row -->
            <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap">
                <h4 class="mb-0 text-center flex-grow-1 text-md-start text-center w-100 w-md-auto">
                    Affiliate Pre-Application Link
                </h4>
                <?php 
                    $reseller_id = get_staff()->agent_id; 
                    $affiliate_link = site_url('pre_application/create?rid=' . $reseller_id);
                ?>
                <div class="input-group" style="max-width: 450px;">
                    <input type="text" id="affiliateLink" 
                           class="form-control text-center"
                           value="<?= $affiliate_link; ?>" readonly>
                    <button class="btn btn-primary" onclick="copyAffiliateLink()">
                        <i class="fa fa-copy"></i> Copy Link
                    </button>
                </div>
            </div>

            <!-- Stat Cards -->
            <div class="row text-center justify-content-center">
                <?php
                $cards = [
                    ['label' => 'Inactive Users', 'count' => $inactive_users_count, 'color' => '#FF3131'],
                    ['label' => 'Active Agents', 'count' => count($active_agents), 'color' => '#22DD22'],
                    ['label' => 'Merchants', 'count' => count($merchants), 'color' => '#0D98BA'],
                    ['label' => 'Pre Applications', 'count' => count($pre_applications), 'color' => '#FDDA0D']
                ];
                foreach ($cards as $card) :
                    $is_custom_color = str_starts_with($card['color'], '#');
                ?>
                    <div class="col-md-3 col-sm-6 mb-4">
                        <div class="card shadow-sm h-100 border-0" 
                             style="<?= $is_custom_color ? "background-color: {$card['color']}; color: #fff;" : "" ?>">
                            <div class="card-body d-flex flex-column justify-content-center align-items-center">
                                <h5 class="mb-2"><?= $card['label'] ?></h5>
                                <p class="display-5 fw-bold mb-0"><?= $card['count'] ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Charts -->
            <div class="row justify-content-center">
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-header text-center fw-semibold">Distribution Overview</div>
                        <div class="card-body">
                            <canvas id="distributionChart" style="max-height: 300px;"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm h-100">
                        <div class="card-header text-center fw-semibold">Growth (Last 30 Days)</div>
                        <div class="card-body">
                            <canvas id="growthChart" style="max-height: 300px;"></canvas>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- Single Footer -->
    <footer class="bg-body-tertiary text-center mt-auto py-3 border-top">
        <div class="container">
            © 2025, Designed and Developed by 
            <a href="https://edatapay.com/" class="fw-semibold text-decoration-none">eData Development Group</a>
        </div>
    </footer>
</div>
<?php init_tail(); ?>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
const distributionCtx = document.getElementById('distributionChart').getContext('2d');
new Chart(distributionCtx, {
    type: 'doughnut',
    data: {
        labels: ['Inactive Users', 'Active Agents', 'Merchants', 'Pre Applications'],
        datasets: [{
            label: 'Distribution',
            data: [<?= $inactive_users_count ?>, <?= count($active_agents) ?>, <?= count($merchants) ?>, <?= count($pre_applications) ?>],
            backgroundColor: ['#FF3131', '#22DD22', '#0D98BA', '#FDDA0D'],
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { position: 'bottom' }
        }
    }
});

const growthCtx = document.getElementById('growthChart').getContext('2d');
new Chart(growthCtx, {
    type: 'bar',
    data: {
        labels: ['Day 1', 'Day 5', 'Day 10', 'Day 15', 'Day 20', 'Day 25', 'Day 30'],
        datasets: [{
            label: 'New Pre Applications',
            data: [2, 4, 3, 6, 5, 8, 10],
            backgroundColor: '#007bff'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: { y: { beginAtZero: true } }
    }
});

function copyAffiliateLink() {
    const input = document.getElementById('affiliateLink');
    input.select();
    input.setSelectionRange(0, 99999);
    navigator.clipboard.writeText(input.value)
        .then(() => alert('Affiliate link copied to clipboard!'))
        .catch(() => alert('Unable to copy link.'));
}
</script>
