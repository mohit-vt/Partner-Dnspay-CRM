<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<style>

.table-responsive {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}
.table-responsive-wrapper table {
    min-width: 1200px !important;
    font-size: 12px !important;  
}  

.status-dropdown {
    color: white;
    font-weight: bold;
    border: none;
    padding: 5px 5px;
    border-radius: 4px;
    width: 100px;
}


.status-dropdown.inactive {
    background-color: #6c757d; /* grey */
}
.status-dropdown.preapp {
    background-color: #ffc107; /* yellow */
}
.status-dropdown.onboarding {
    background-color: #17a2b8; /* teal */
}
.status-dropdown.underwriting {
    background-color: #fd7e14; /* orange */
}
.status-dropdown.bank {
    background-color: #007bff; /* blue */
}
.status-dropdown.management {
    background-color: #6610f2; /* purple */
}
.status-dropdown.live {
    background-color: #28a745; /* green */
}
.status-dropdown.approved {
    background-color: #20c997; /* lighter green */
}
.status-dropdown.closed {
    background-color: #dc3545; /* red */ 
}
.status-dropdown.declined {
    background-color: #dc3545; /* violet */
}


/* I am not the orginal creator */
.toggleWrapper {
    /*position: absolute;
    /* top: 50%;
    padding: 0px 164px; 
    left: 86%;*/

    overflow: hidden;
    /* transform: translate3d(-50%, -50%, 0); */
    color: white;
}

.toggleWrapper .input {
  position: absolute;
  left: -99em;
}

.toggle {
  cursor: pointer;
  display: inline-block;
  position: relative;
  width: 65px;
  height: 25px;
  background-color: red;
  border-radius: 84px;
 
}

.toggle:before {
  content: "Yes";
  position: absolute;
  left: 7px;
  top: 3px;
  font-size: 13px;
  color: red;
}

.toggle:after {
  content: "No";
  position: absolute;
  right: 7px;
  top: 3px;
  font-size: 13px;
  color: white;
}

.toggle__handler {
  display: inline-block;
  position: relative;
  z-index: 1;
  top: 3px;
  left: 3px;
  width: 20px;
  height: 20px;
  background-color: white;
  border-radius: 50px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
  transition: all 400ms cubic-bezier(0.68, -0.55, 0.265, 1.55);
  transform: rotate(-45deg);
}

.input:checked + .toggle {
  background-color: green;
}

.input:checked + .toggle:before {
  color: white;
}

.input:checked + .toggle:after {
  color: green;
}

.input:checked + .toggle .toggle__handler {
  background-color: white;
  transform: translate3d(40px, 0, 0) rotate(0);
}

.input:checked + .toggle .toggle__handler .crater {
  opacity: 1;
}


</style>
<div id="wrapper">
    <div class="content">
        <div class="row">
            <div class="col-md-12">
            <h4 class="tw-my-0 tw-font-bold tw-text-xl">Pipeline Report</h4>
            <hr>


                <div class="panel_s">
                    <div class="panel-body">
                    <a href="<?php echo base_url('reseller/pipeline_report/create'); ?>" class="btn btn-primary">Add New Application</a>
                    <!--<button class="btn btn-danger" id="delete_selected">Delete</button>-->
                    <hr>
           
<div class="table-responsive" style="font-size:11px !important;">
    <table class="table dt-table table-striped" data-order-col="7" data-order-type="desc" id="pipelineTable">
      
               
<thead>
    <tr>
        <th>Lead Source</th>
        <th>Company Name</th>
        <th>DBA Name</th>
        <th>Location</th>  
        <?php
        $rolevalue = $this->roles_model->get($current_user->role);
        if (isset($rolevalue->name) && $rolevalue->name != "agent" && $rolevalue->name != "reseller") {
        ?>
            <th>Agent Name Contact</th>
        <?php } ?> 
        <th>Email</th>
        <th>Cell Phone Number</th>
        <th>Bank Name</th>
        <th>Date Recieved</th>
        <th>Match/TMF</th>
        <th>UBO</th>
        <!--<th>Status</th>-->
        <th>Copy</th>
        <th>Manage</th>
        <th>Alerts</th>
      <th>Status</th>
     <th>Assignment Type</th>
        <th class="no-sort">Log</th>
    </tr>
</thead>

    <tbody>

        <?php $index = 1; foreach ($combined_list as $item): ?>
        <tr style="display: table-row !important;">


           
            <td><?= isset($item['lead_source']) ? htmlspecialchars($item['lead_source']) : ''; ?></td>

            <td><?= htmlspecialchars($item['company_name'] ?? '') ?></td>
  		<td>
        <?= htmlspecialchars($item['dba'] ?? '') ?>
      	</td>
 		<?php
            $business_country = isset($item['user_business_country']) ? $item['user_business_country'] : '';
            $pipeline_report_country = isset($item['pipeline_report_country']) ? $item['pipeline_report_country'] : '';

            $country_val = !empty($business_country) ? $business_country : $pipeline_report_country;

            $country_name = '';
            if (!empty($country_val)) {
                if (is_numeric($country_val)) {
                    // It's an ID → get country name
                    $country = get_country($country_val);
                    $country_name = $country ? $country->short_name : $country_val;
                } else {
                    // It's already a name → use directly
                    $country_name = $country_val;
                }
            }
            ?>
            <td><?= htmlspecialchars($country_name); ?></td>

                      <?php $rolevalue = $this->roles_model->get($current_user->role);
   if (isset($rolevalue->name) && $rolevalue->name != "agent" && $rolevalue->name != "reseller" ) { ?>
           <?php
  			$first_name = $item['staff_firstname'] ?? $item['first_name'] ?? '';
			$last_name = $item['staff_lastname'] ?? $item['last_name'] ?? '';
			$full_name = trim($first_name . ' ' . $last_name);

            ?>
            <td><?= htmlspecialchars(!empty($full_name) ? $full_name : $full_name); ?></td>
          
            <?php } ?>

      <td>
        <?= htmlspecialchars($item['final_email'] ?? '') ?>
      </td>

          <td><?= htmlspecialchars($item['business_phone'] ?? '') ?></td>
           <?php  
          	$bank_name = isset($item['pipeline_bank']) ? $item['pipeline_bank'] : '';
            $pipeline_report_bank_name = isset($item['pipeline_report_bank_name']) ? $item['pipeline_report_bank_name'] : '';
            ?>
           <td><?= htmlspecialchars(!empty($bank_name) ? $bank_name : $pipeline_report_bank_name); ?></td>
          
            <?php
            $date_received = isset($item['created_at']) ? $item['created_at'] : '';
            $application_date = isset($item['application_date']) ? $item['application_date'] : '';
            ?>
           <td><?= htmlspecialchars(!empty($date_received) ? $date_received : $application_date); ?></td>

<td>

<?php if(isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "New"){ ?>



        <?php }else if((isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "Completed")){ ?>
    <?php $math_id = 'match_tmf_' . $index++; ?>
    <input class="input match-toggle" data-field="match_tmf" data-id="<?= isset($item['pipeline_report_id']) ? htmlspecialchars($item['pipeline_report_id']) : '' ?>" id="<?= $math_id ?>" type="checkbox" style="display:none" <?= (isset($item['match_tmf']) && $item['match_tmf'] === 'Yes') ? 'checked' : '' ?> />
    <label class="toggle" for="<?= $math_id ?>">
        <span class="toggle__handler"></span>
    </label>
         <?php }else{ ?>
    <?php $math_id = 'match_tmf_' . $index++; ?>
    <input class="input match-toggle" data-field="match_tmf" data-id="<?= isset($item['pipeline_report_id']) ? htmlspecialchars($item['pipeline_report_id']) : '' ?>" id="<?= $math_id ?>" type="checkbox" style="display:none" <?= (isset($item['match_tmf']) && $item['match_tmf'] === 'Yes') ? 'checked' : '' ?> />
    <label class="toggle" for="<?= $math_id ?>">
        <span class="toggle__handler"></span>
    </label>
       <?php } ?>

</td>
<td>
<?php if(isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "New"){ ?>



        <?php }else if((isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "Completed")){ ?>
    <?php $ubo_id = 'ubo_' . $index++; ?>
    <input class="input match-toggle" data-field="ubo" data-id="<?= isset($item['pipeline_report_id']) ? htmlspecialchars($item['pipeline_report_id']) : '' ?>" id="<?= $ubo_id ?>" type="checkbox" style="display:none" <?= (isset($item['ubo']) && $item['ubo'] === 'Yes') ? 'checked' : '' ?> />
    <label class="toggle" for="<?= $ubo_id ?>">
        <span class="toggle__handler"></span>
             <?php }else{ ?>
                    <?php $ubo_id = 'ubo_' . $index++; ?>
    <input class="input match-toggle" data-field="ubo" data-id="<?= isset($item['pipeline_report_id']) ? htmlspecialchars($item['pipeline_report_id']) : '' ?>" id="<?= $ubo_id ?>" type="checkbox" style="display:none" <?= (isset($item['ubo']) && $item['ubo'] === 'Yes') ? 'checked' : '' ?> />
    <label class="toggle" for="<?= $ubo_id ?>">
        <span class="toggle__handler"></span>
          <?php } ?>
    </label>
</td>

<!--<td>   
<?php if ($pre_application_merchant_status == "true") { ?>  
<select
    style="height: 30px !important;width: 112px !important;"
    class="status-dropdown form-control"
    data-id="<?= $item['pipeline_report_id'] ?>"
    onchange="updateSelectColor(this)" disabled>
    <option value="Inactive" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Inactive') ? 'selected' : '' ?>>Inactive</option>
	<option value="PreAPP" <?= (isset($item['merchant_status_final']) && strcasecmp($item['merchant_status_final'], 'PreAPP') === 0) ? 'selected' : '' ?>>PreAPP</option>
    <option value="Onboarding" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Onboarding') ? 'selected' : '' ?>>Onboarding</option>
    <option value="Bank" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Bank') ? 'selected' : '' ?>>Bank</option>
    <option value="Management" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Management') ? 'selected' : '' ?>>Management</option>
    <option value="Approved" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Approved') ? 'selected' : '' ?>>Approved</option>
    <option value="Live" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Live') ? 'selected' : '' ?>>Live</option>
    <option value="Closed" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Closed') ? 'selected' : '' ?>>Closed</option>
</select>
<?php } else { ?>
                                    
<button
    class="btn btn-sm cancel-button <?= $item['pipeline_merchant_status'] === 'Cancel' ? 'btn-danger' : 'btn-warning'; ?>"
    data-id="<?= $item['pipeline_report_id']; ?>"
    data-status="<?= $item['pipeline_merchant_status']; ?>">
    <?= $item['pipeline_merchant_status'] === 'Cancel' ? 'Cancelled' : 'Cancel'; ?>
</button>



<?php } ?>
</td>-->
    <td>
<?php if(isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "New"){ ?>



        <?php }else if((isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "Completed")){ ?>

        <a href="<?= site_url('reseller/pipeline_report/copy/' . ($item['pipeline_report_id'] ?? '')) ?>" style="color:white" class="btn btn-sm btn-primary"><i class="fa fa-copy"></i> Copy </a>
      
       <?php }else{ ?>

        <a href="<?= site_url('reseller/pipeline_report/copy/' . ($item['pipeline_report_id'] ?? '')) ?>" style="color:white" class="btn btn-sm btn-primary"><i class="fa fa-copy"></i> Copy </a>
        
        <?php } ?>
    </td>
    <td>
<?php if (isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "New") { ?>

    <?php if (!empty($item['ip_address'])) { ?>
        <a style="background:#90D5FF !important" 
           href="<?php echo site_url('reseller/pipeline_report/view/' . ($item['pipeline_report_id'] ?? '')); ?>" 
           class="btn btn-sm btn-info">Manage</a>
    <?php } else { ?>
        <a style="background:#90D5FF !important" 
           href="<?php echo site_url('reseller/pipeline_report/create/' . ($item['app_id'] ?? '')); ?>" 
           class="btn btn-sm btn-info">Manage</a>
    <?php } ?>

<?php } else { ?>

    <a style="background:#90D5FF !important" 
       href="<?php echo site_url('reseller/pipeline_report/view/' . ($item['pipeline_report_id'] ?? '')); ?>" 
       class="btn btn-sm btn-info">Manage</a>

<?php } ?>

    </td>
    <td style="text-align:center !important">
    <?php if (!empty($item['is_duplicate'])): ?>
        <button class="btn btn-sm bg-danger view-duplicates"
                data-key="<?= strtolower(trim($item['email_address'])) . '|' . trim($item['contact_phone']) . '|' . strtolower(trim($item['pipeline_report_bank_name'])) ?>">
            Duplication Alerts
        </button>
    <?php endif; ?>
    </td>
    <td>    
<select 
    style="height: 30px !important;width: 112px !important;"
    class="status-dropdown form-control"
    data-id="<?= $item['pipeline_report_id'] ?>"
    onchange="updateSelectColor(this)">
    <option value="Inactive" <?= (isset($item['pipeline_merchant_status']) && $item['pipeline_merchant_status'] == 'Inactive') ? 'selected' : '' ?>>Inactive</option>
	<option value="PreAPP" <?= (isset($item['pipeline_merchant_status']) && strcasecmp($item['pipeline_merchant_status'], 'PreAPP') === 0) ? 'selected' : '' ?>>PreAPP</option>
    <option value="Onboarding" <?= (isset($item['pipeline_merchant_status']) && $item['pipeline_merchant_status'] == 'Onboarding') ? 'selected' : '' ?>>Onboarding</option>
    <option value="Bank" <?= (isset($item['pipeline_merchant_status']) && $item['pipeline_merchant_status'] == 'Bank') ? 'selected' : '' ?>>Bank</option>
    <option value="Management" <?= (isset($item['pipeline_merchant_status']) && $item['pipeline_merchant_status'] == 'Management') ? 'selected' : '' ?>>Management</option>
    <option value="Approved" <?= (isset($item['pipeline_merchant_status']) && $item['pipeline_merchant_status'] == 'Approved') ? 'selected' : '' ?>>Approved</option>
    <option value="Live" <?= (isset($item['pipeline_merchant_status']) && $item['pipeline_merchant_status'] == 'Live') ? 'selected' : '' ?>>Live</option>
    <option value="Closed" <?= (isset($item['pipeline_merchant_status']) && $item['pipeline_merchant_status'] == 'Closed') ? 'selected' : '' ?>>Closed</option>
      <option value="Declined" <?= (isset($item['pipeline_merchant_status']) && $item['pipeline_merchant_status'] == 'Declined') ? 'selected' : '' ?>>Declined</option>
</select>

</td>
          <td><?= htmlspecialchars($item['assignment_type']); ?></td>

    <td>
         <?php if(isset($item['pipeline_report_id'])){ ?>
        <a href="<?= site_url('reseller/pipeline_report/activity_log/' . ($item['pipeline_report_id'] ?? '')) ?>" 
        class="btn btn-sm btn-secondary">
        <i class="fa fa-history me-1"></i> Log
        </a>
          <?php } ?>

    </td>

    </tr>
        <?php endforeach; ?>
    </tbody>
</table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Duplicate Details Modal -->
<div class="modal fade" id="duplicateModal" tabindex="-1" role="dialog" aria-labelledby="duplicateModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="text-danger"><i class="fa fa-exclamation-triangle mr-2"></i>Duplicate Applications Detected</h5>
        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="duplicateModalBody">
        Loading...
      </div>
    </div>
  </div>
</div>

<?php init_tail(); ?>

<!-- Load circleProgress plugin BEFORE your custom scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/circle-progress/1.2.2/circle-progress.min.js"></script>

<script>
  
  //$('.status-dropdown').css('pointer-events','none');

function updateSelectColor(selectElement) {
    if (!selectElement || !selectElement.classList) return; // safety

    // Remove all status classes
    selectElement.classList.remove(
        'preapp','onboarding','underwriting','bank','declined',
        'management','inactive', 'approved', 'live', 'closed'
    );

    // Add class based on selected value
    const status = selectElement.value?.toLowerCase(); // like "approved"
    if (status) {
        selectElement.classList.add(status);
    }
}


// On page load, initialize all status-dropdowns with the right color
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".status-dropdown").forEach(function (el) {
        updateSelectColor(el);
    });
});

$(document).on('change', '.status-dropdown', function () {
    var $dropdown = $(this);
    updateSelectColor(this); // safe call here

    var newStatus = $dropdown.val();
    var id = $dropdown.data('id');

    $.ajax({
        type: "POST",
        url: admin_url + "pipeline_report/update_status",
        data: { id: id, status: newStatus },
        success: function (response) {
            var data = JSON.parse(response);
            if (data.success) {
                // Optionally apply color class again
                updateSelectColor($dropdown[0]);
            } else {
                alert('Failed to update status.');
            }
        },
        error: function () {
            alert('Server error while updating status.');
        }
    });
});

$(document).on('click', '.cancel-button', function () {
    var $btn = $(this);
    var id = $btn.data('id');
    var currentStatus = $btn.data('status');

    // Already cancelled
    if (currentStatus === 'Cancel') {
        return;
    }

    // Optimistic UI update
    $btn
        .removeClass('btn-warning')
        .addClass('btn-danger')
        .text('Cancelled')
        .data('status', 'Cancel');

    $.ajax({
        type: "POST",
        url: admin_url + "pipeline_report/update_status",
        data: { id: id, status: 'Cancel' },
        success: function (response) {
            var data = JSON.parse(response);
            if (!data.success) {
                alert('Failed to update: ' + (data.message || 'Unknown error'));
            }
        },
        error: function () {
            alert('Server error while cancelling.');
        }
    });
});


    // circleProgress example (safe check)
    if ($.fn.circleProgress) {
        $('.progress-circle').circleProgress({
            value: 0.75
        });
    } else {
        console.warn("circleProgress plugin not loaded");
    }

    // Helper to color Yes/No
    function updateStatusColor(selectElement, status) {
        selectElement.removeClass('yes no');
        switch (status.toLowerCase()) {
            case 'yes': selectElement.addClass('yes'); break;
            case 'no': selectElement.addClass('no'); break;
        }
    }

</script>


<?php
// Disable right-click for specific roles
$rolevalue = $this->roles_model->get($current_user->role);
if (isset($rolevalue->name) && in_array($rolevalue->name, ["agent", "reseller", "partner admin"])): ?>
<script>
  document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
  });

  document.onkeydown = function(e) {
    if (
      e.keyCode === 123 || // F12
      (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I/J
      (e.ctrlKey && e.keyCode === 85) // Ctrl+U
    ) {
      return false;
    }
  };
</script>
<?php endif; ?>


