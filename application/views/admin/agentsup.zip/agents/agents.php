<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<div id="wrapper">
    <div class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="panel_s">
                    <div class="panel-body">
                        <h3 class="no-margin"><b>Sub - Agent Reseller Application</b></h3>
                        <hr>
                            <div class="card-body" ><h4 class="no-margin"><b>ISO/Agent Information</b></h4></div>
                        <hr>
                        <?php echo form_open(admin_url('agents/submit'), ['class' => 'agents-form']); ?>

                        <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
                        <?php
                            $last_name = '';
                            foreach ($custom_fields as $field) {
                                if ($field['name'] === 'Last Name') {
                                    $last_name = html_escape($field['value']);
                                    break;
                                }
                            }
                        ?>
                        <div class="row">
                           <!-- Affiliation -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="affiliation">Affiliation</label>
                                    <input type="text" id="affiliation" name="affiliation" class="form-control" required>
                                </div>
                            </div> 
                            <!-- ISO Office -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="iso_office">ISO Office</label>
                                    <input type="text" id="iso_office" name="iso_office" class="form-control" required>
                                </div>
                            </div>

                            <!-- Agent Name -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="agent_name">Agent Name</label>
                                   <input type="text" id="agent_name" name="agent_name"
    value="<?= htmlspecialchars(($lead['name'] ?? '') . ' ' . $last_name); ?>" class="form-control" required>

                                </div>
                            </div>

                            <!-- Agent Number -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="agent_number">Agent Number</label>
                                    <input type="text" id="agent_number" name="agent_number" class="form-control" maxlength="7" required>
                                </div>
                            </div>
                        </div>    

                <hr>
                    <div class="card-body" >
                        <h4 class="no-margin"><b>Merchant/Opportunity Details</b></h4>
                    </div>
                <hr>

                            <div class="row">

                            <!-- Opportunity Name -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="opportunity_name">Opportunity Name</label>
                                    <input type="text" id="opportunity_name" name="opportunity_name" class="form-control" required>
                                </div>
                            </div>

                            <!-- Company DBA Name -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="company_dba">DBA Name</label>
                                    <input type="text" id="company_dba" name="company_dba" class="form-control" required>
                                </div>
                            </div>

                               <!-- Company Name -->
                        <div class="col-md-12">
                                <div class="form-group">
                                    <label for="company_name">Company Name</label>
                                    <input type="text" name="company_name" id="company_name" size="30" maxlength="255" title="Company Name" tabindex="0" class="form-control">
                                </div>
                        </div>

                                        <?php
                            $last_name = '';
                            foreach ($custom_fields as $field) {
                                if ($field['name'] === 'Last Name') {
                                    $last_name = html_escape($field['value']);
                                    break;
                                }
                            }
                            ?>

                        <!-- Website -->
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label for="company_website">Website</label>
                                    <input type="text" name="company_website" id="company_website" value="<?= htmlspecialchars(($lead['website'] ?? '')); ?>"  size="30" maxlength="255" title="Company Website" tabindex="0" class="form-control">
                                </div>
                        </div>

                                                     
                        <!-- Technology Type -->
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label for="tech_type">Technology Type</label>
                                    <input type="text" id="tech_type" name="tech_type" class="form-control">
                                </div>
                        </div>

                        <!-- Monthly Sales Revenue -->
                        <div class="col-md-12">
                                <div class="form-group">
                                    <label for="monthly_revenue">Monthly Revenue</label>
                                    <input type="text" id="monthly_revenue" value="$" name="monthly_revenue" class="form-control">
                                </div>
                        </div>
                    </div>
                     
                <hr>
                    <div class="card-body" >
                        <h4 class="no-margin"><b>Contact Information</b></h4>
                    </div>
                <hr>

                    <div class="row">
                        <!-- First Name -->
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label for="first_name">First Name</label>
                                    <input type="text" id="first_name" name="first_name" value="<?= htmlspecialchars(($lead['name'] ?? '')); ?>" class="form-control">
                                </div>
                        </div>


                        <!-- Last Name -->
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label for="last_name">Last Name</label>
                                    <input type="text" id="last_name" name="last_name" value="<?= $last_name; ?>" class="form-control">
                                </div>
                        </div>

                        <!-- Email -->
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="text" id="email" name="email" value="<?= htmlspecialchars(($lead['name'] ?? '')); ?>" class="form-control">
                                </div>
                        </div>

                        <!-- Phone -->
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label for="phone">Phone</label>
                                    <input type="text" id="phone" name="phone" value="<?= htmlspecialchars(($lead['phonenumber'] ?? '')); ?>" class="form-control">
                                </div>
                        </div>
                     

                        <!-- Executive Title -->
                        <div class="col-md-12">
                                <div class="form-group">
                                    <label for="executive_type">Executive Title</label>
                                    <input type="text" id="executive_type" name="executive_type" class="form-control">
                                </div>
                        </div>
                    </div>

                    <hr>
                    <div class="card-body" >
                        <h4 class="no-margin"><b>Application & Underwriting</b></h4>
                    </div>
                <hr>

                    <div class="row">

                        <!-- Date Received -->
                        <div class="col-md-6">
                            <div class="form-group">
                                    <label for="date_received">Date Received</label>
                                    <input type="date" id="date_received" name="date_received" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                                </div>
                            </div>

                        <!-- Status -->
                         <div class="col-md-6">
                                <div class="form-group">
                                    <label for="status">Status</label>
                                    <select id="status" name="status" class="form-control" required>
                                        <option value="Lead" selected>Lead</option>
                                        <option value="Reseller">Reseller</option>
                                    </select>
                                </div>
                            </div>    

                        <!-- Full or Partial App -->
                        <div class="col-md-12">
                                <div class="form-group">
                                    <label for="full_partial_app">Full/Partial App</label>
                                    <textarea id="full_partial_app" name="full_partial_app" class="form-control"></textarea>
                                </div>
                        </div>
                        
                        <!-- Underwriting Status -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="underwriting_status">Underwriting Status</label>
                                    <input type="text" id="underwriting_status" name="underwriting_status" class="form-control">
                                </div>
                            </div>

                         <!-- Reason for Rejection -->
                        <div class="col-md-12">
                                <div class="form-group">
                                    <label for="reason">Reason for Rejection</label>
                                    <textarea id="reason" name="reason" class="form-control" rows="1"></textarea>
                                </div>
                        </div>
                    </div>

                    <hr>
                    <div class="card-body" >
                        <h4 class="no-margin"><b>Financial Information</b></h4>
                    </div>
                <hr>

                    <div class="row">

                            <!-- Volume per application -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="volume">Volume per application</label>
                                    <input type="text" id="volume" name="volume" value="$" class="form-control">
                                </div>
                            </div>



                            <!-- Acquiring Region -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="acquiring_location">Acquiring Region</label>
                                    <select id="acquiring_location" name="acquiring_location" class="form-control">
                                        <option value="US" selected>US</option>
                                        <option value="EU">EU</option>
                                        <option value="LATM">LATM</option>
                                        <option value="AFRICA">AFRICA</option>
                                        <option value="ASIA">ASIA</option>
                                    </select>
                                </div>
                            </div>
                        </div>  
                        
                        <hr>
                    <div class="card-body" >
                        <h4 class="no-margin"><b>Comments</b></h4>
                    </div>
                <hr>

                    <div class="row">

                            <!-- General Comments -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="comments1">General  Comments</label>
                                    <textarea id="comments1" name="comments1" class="form-control"></textarea>
                                </div>
                            </div>

                            <!-- Management Comments -->
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="management_comments">Management Comments</label>
                                    <textarea id="management_comments" name="management_comments" class="form-control"></textarea>
                                </div>
                            </div>
                            </div>  
                        
                  <?php 
    $rolevalue = $this->roles_model->get($current_user->role);

    if (
    ($this->app->show_setup_menu() == true && (is_staff_member() || is_admin())) &&
    isset($rolevalue->name) &&
    !in_array($rolevalue->name, ['agent', 'reseller', 'partner admin'])
    ) { 
    ?>        
                        <hr>
                    <div class="card-body" >
                        <h4 class="no-margin"><b>Assignment</b></h4>
                    </div>
                <hr>
                    <!-- In House Employee -->
                    <div class="row">
                    <div class="col-md-12">
                                <div class="form-group">
                                    <label for="assigned_inhouse">In House Employee</label>
                                    <select id="assinged_inhouse" name="assinged_inhouse" class="form-control">
                                    <option value="" selected>Select In-House Users</option>
                                    <?php $selected_staff_id = $selected_staff_id ?? ''; ?>
                                    <?php foreach ($staff_inhouse as $member): ?>
                                        <option value="<?= $member->staffid ?>" <?= $member->staffid == $selected_staff_id ? 'selected' : '' ?>>
                                            <?= $member->firstname . ' ' . $member->lastname ?>
                                        </option>
                                    <?php endforeach; ?>
                                    </select>
                                </div>
                        </div>

                        <!-- Assigned Agent -->
                        <div class="col-md-12">
                                <div class="form-group">
                                    <label for="assigned_agent">Assigned Agent</label>
                                    <select id="assigned_agent" name="assigned_agent" class="form-control">
                                    <option value="" selected>Select Agents</option>
                                    <?php $selected_staff_id = $selected_staff_id ?? ''; ?>
                                    <?php foreach ($staff_agents as $member): ?>
                                        <option value="<?= $member->staffid ?>" <?= $member->staffid == $selected_staff_id ? 'selected' : '' ?>>
                                            <?= $member->firstname . ' ' . $member->lastname ?>
                                        </option>
                                    <?php endforeach; ?>
                                    </select>
                                </div>
                        </div>

                        <?php } ?>
                  
                    </div>

                        <!-- Submit Button -->
                        <div class="panel-footer text-right">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>

                        <?php echo form_close(); ?>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php init_tail(); ?>
<script>
  <?php $rolevalue = $this->roles_model->get($current_user->role);
if (isset($rolevalue->name) && ($rolevalue->name == "agent" || $rolevalue->name == "reseller" || $rolevalue->name == "partner admin")) {  ?>
    // Disable Right-Click

  document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
  });

  // Disable Keyboard Shortcuts (like F12, Ctrl+Shift+I, Ctrl+U)
  document.onkeydown = function(e) {
    if (
      e.keyCode === 123 || // F12
      (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I or Ctrl+Shift+J
      (e.ctrlKey && e.keyCode === 85) // Ctrl+U
    ) {
      return false;
    }
  };
   <?php } ?>


</script>