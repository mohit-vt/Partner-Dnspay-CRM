<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<style>
  
  
/* Top scrollbar sync styling */
.scrollbar-top {
  overflow-x: auto;
  height: 16px;
}
.scrollbar-top div {
  height: 1px;
}
  
  /* Sorting indicator */
th.sortable {
  cursor: pointer;
}
th.sortable::after {
  content: " ⇅";
  font-size: 12px;
  color: #888;
}
  .badge-light {
    background-color: #f9f9f9;
    color: #333;
    font-size: 12px;
    border-radius: 6px;
    display: inline-block;
    white-space: nowrap;
    max-width: 100%;
    overflow: hidden;
    text-overflow: ellipsis;
}

.status-dropdown {
    color: white;
    font-weight: bold;
    border: none;
    padding: 5px 5px;
    border-radius: 4px;
    width: 100px;
}

  .status-dropdown.yes {
    background-color: #008000; /* yellow */
}

.status-dropdown.no {
    background-color: #dc3545; /* red */
}
/* Container for vertical + horizontal scroll */
.table-wrapper {
  max-height: 70vh;      /* vertical scroll limit */
  overflow-y: auto;       /* vertical scroll */
  overflow-x: hidden;     /* horizontal scroll handled separately */
  position: relative;
  border: 1px solid #ddd;
  border-radius: 6px;
}

/* Top horizontal scrollbar */
.scrollbar-top {
  overflow-x: auto;
  overflow-y: hidden;
  width: 100%;
}
.scrollbar-top > div {
  height: 1px; /* dummy div to match table width */
}

/* Table styling */
#pipelineTable {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}

/* Sticky header */
#pipelineTable thead th {
  position: sticky;
  top: 0;
  background: #f1f1f1;
  z-index: 10;
  border-bottom: 2px solid #ccc;
  text-align: center;
  padding: 8px;
}

/* Table cells */
#pipelineTable td, #pipelineTable th {
  padding: 8px 10px;
  border: 1px solid #ddd;
}

/* Optional: nice scrollbar */
.table-wrapper::-webkit-scrollbar {
  width: 10px;
}
.table-wrapper::-webkit-scrollbar-thumb {
  background: #bbb;
  border-radius: 5px;
}
.table-wrapper::-webkit-scrollbar-thumb:hover {
  background: #999;
}

/* Status colors */
.status-dropdown.inactive { background-color: grey; color: white; }
.status-dropdown.preapp { background-color: #f0ad4e; color: white; }
.status-dropdown.onboarding { background-color: #ffc107; color: white; }
.status-dropdown.bank { background-color: #17a2b8; color: white; }
.status-dropdown.management { background-color: #dc3545; color: white; }
.status-dropdown.approved { background-color: #28a745; color: white; }
.status-dropdown.live { background-color: #007bff; color: white; }
.status-dropdown.closed { background-color: #6c757d; color: white; }
.status-dropdown.declined { background-color: #dc3545; color: white; }
  

/* I am not the orginal creator */
.toggleWrapper {
    /*position: absolute;
    /* top: 50%;
    padding: 0px 164px; 
    left: 86%;*/

    overflow: hidden;
    /* transform: translate3d(-50%, -50%, 0); */
    color: white;
}

.toggleWrapper .input {
  position: absolute;
  left: -99em;
}

.toggle {
  cursor: pointer;
  display: inline-block;
  position: relative;
  width: 65px;
  height: 25px;
  background-color: red;
  border-radius: 84px;
 
}

.toggle:before {
  content: "Yes";
  position: absolute;
  left: 7px;
  top: 3px;
  font-size: 13px;
  color: red;
}

.toggle:after {
  content: "No";
  position: absolute;
  right: 7px;
  top: 3px;
  font-size: 13px;
  color: white;
}

.toggle__handler {
  display: inline-block;
  position: relative;
  z-index: 1;
  top: 3px;
  left: 3px;
  width: 20px;
  height: 20px;
  background-color: white;
  border-radius: 50px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
  transition: all 400ms cubic-bezier(0.68, -0.55, 0.265, 1.55);
  transform: rotate(-45deg);
}

.input:checked + .toggle {
  background-color: green;
}

.input:checked + .toggle:before {
  color: white;
}

.input:checked + .toggle:after {
  color: green;
}

.input:checked + .toggle .toggle__handler {
  background-color: white;
  transform: translate3d(40px, 0, 0) rotate(0);
}

.input:checked + .toggle .toggle__handler .crater {
  opacity: 1;
}

  
.badge-danger {
    background-color: #dc3545 !important;
    color: #fff !important;
}
</style>

<div id="wrapper">
  <div class="content">
    <div class="row">
      <div class="col-md-12">
        <div class="panel_s">
          <div class="panel-body">
            <a href="<?= admin_url('pipeline_report/create'); ?>" class="btn btn-primary">Add New Application</a>
            <hr>
<!-- Filter + Search row (flex layout: filter left, search right) -->
<div class="mb-3 d-flex align-items-center justify-content-between" style="gap:12px;">
  
    <label for="statusFilter" style="margin-right:8px;"><strong>Filter by Status:</strong></label>
    <select id="statusFilter" class="form-control" style="width:220px;">
      <option value="">All</option>
      <option value="Approved">Approved</option>
      <option value="Inactive">Inactive</option>
      <option value="PreAPP">PreAPP</option>
      <option value="Onboarding">Onboarding</option>
      <option value="Bank">Bank</option>
      <option value="Management">Management</option>
      <option value="Live">Live</option>
      <option value="Closed">Closed</option>
    </select>


  <!-- search on the right -->
  <div class="d-flex align-items-center" style="float:right">
    <label for="tableSearch" style="margin-right:8px;"><strong>Search:</strong></label>
    <input type="text" id="tableSearch" class="form-control" 
           placeholder="Search any column (Agent, Company, Email...)" 
           style="width:320px;">
  </div>
</div>


            <!-- Top horizontal scrollbar -->
            <div class="scrollbar-top"><div></div></div>

            <!-- Table wrapper with vertical scroll -->
            <div class="table-wrapper">
              <table class="table table-striped" id="pipelineTable">
                   <thead>
        <tr>
            <th>Lead Source</th>
            <th>Company Name</th>
            <th>DBA Name</th>
            <th>Location</th>  
            <th>Agent Name</th> <!-- Always included, hide via CSS if not needed -->
            <th>Owner</th>
            <th>Email</th>
            <th>Cell Phone Number</th>
            <th>Bank Name</th>
            <th>Date Recieved</th>
            <th>Match/TMF</th>
            <th>UBO</th>
          	<th>Social Media</th>
            <th>Status</th>
            <th>Copy</th>
            <th>Manage</th>
            <th>Alerts</th>
          <th>Download</th>
            <th>Activity Log</th>
           <th class="<?= (!is_admin()) ? 'd-none' : '' ?>">Delete</th>
          <th>Archieved</th>
          <th>Cancel</th>
           <th>Application Source</th>
        </tr>
    </thead>
                </thead>
                <tbody>
                  <?php  $index = 1; foreach ($combined_list as $item): 
                
// Detect the record type
$is_preapp = (isset($item['merchant_status_final']) && strcasecmp($item['merchant_status_final'], 'PreAPP') === 0);
$record_id = $is_preapp ? ($item['app_id'] ?? '') : ($item['pipeline_report_id'] ?? '');
$record_status = $is_preapp ? 'PreApp' : 'pipeline';
?>
        <tr>

           
     <td><?= isset($item['lead_source']) ? htmlspecialchars($item['lead_source']) : ''; ?></td>
    <td>
        <?= htmlspecialchars($item['final_company'] ?? '') ?>
    </td>

 
            <?php
            $business_system = isset($item['business_system']) ? $item['business_system'] : '';
            $dba = isset($item['dba']) ? $item['dba'] : '';
            ?>
            <td><?= htmlspecialchars(!empty($business_system) ? $business_system : $dba); ?></td>
            <?php
            $business_country = isset($item['user_business_country']) ? $item['user_business_country'] : '';
            $pipeline_report_country = isset($item['pipeline_report_country']) ? $item['pipeline_report_country'] : '';

            $country_val = !empty($business_country) ? $business_country : $pipeline_report_country;

            $country_name = '';
            if (!empty($country_val)) {
                if (is_numeric($country_val)) {
                    // It's an ID → get country name
                    $country = get_country($country_val);
                    $country_name = $country ? $country->short_name : $country_val;
                } else {
                    // It's already a name → use directly
                    $country_name = $country_val;
                }
            }
            ?>
    <td><?= htmlspecialchars($country_name); ?></td>
      <!-- Agent Name -->
            <?php
            $rolevalue = $this->roles_model->get($current_user->role);
            $first_name = $item['staff_firstname'] ?? $item['first_name'] ?? '';
            $last_name  = $item['staff_lastname'] ?? $item['last_name'] ?? '';
            $full_name  = trim($first_name . ' ' . $last_name);
            ?>
            <!--<td class="<?= ($rolevalue->name == 'agent') ? 'd-none' : '' ?>">
                <?= ($rolevalue->name != 'agent') ? htmlspecialchars($full_name) : ''; ?>
            </td>-->
    <td>
        <?php
        $agentId = $item['assigned_to_agent'] ?? null;
        echo isset($agent_map[$agentId]) 
            ? htmlspecialchars($agent_map[$agentId]) 
            : '';
        ?>
    </td>
    <td>
        <?= htmlspecialchars(trim(($item['final_first_name'] ?? '') . ' ' . ($item['final_last_name'] ?? ''))) ?>
    </td>
    <td>
        <?= htmlspecialchars($item['final_email'] ?? '') ?>
    </td>
    <td>
        <?= htmlspecialchars($item['final_phone'] ?? '') ?>
    </td>
    <td>
        <?= htmlspecialchars($item['final_bank_name'] ?? '') ?>
    </td>
          
    <td>
        <?= htmlspecialchars($item['final_created_at'] ?? '') ?>
    </td>

<td>

<?php if(isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "New"){ ?>
    <td>
        <?= htmlspecialchars($item['final_phone'] ?? '') ?>
    </td>


        <?php }else if((isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "Completed")){ ?>
    <?php $math_id = 'match_tmf_' . $index++; ?>
    <input class="input match-toggle" data-field="match_tmf" data-id="<?= isset($item['pipeline_report_id']) ? htmlspecialchars($item['pipeline_report_id']) : '' ?>" id="<?= $math_id ?>" type="checkbox" style="display:none" <?= (isset($item['match_tmf']) && $item['match_tmf'] === 'Yes') ? 'checked' : '' ?> />
    <label class="toggle" for="<?= $math_id ?>">
        <span class="toggle__handler"></span>
    </label>
         <?php }else{ ?>
    <?php //$math_id = 'match_tmf_' . $index++; ?>
    <!--<input class="input match-toggle" data-field="match_tmf" data-id="<?= isset($item['pipeline_report_id']) ? htmlspecialchars($item['pipeline_report_id']) : '' ?>" id="<?= $math_id ?>" type="checkbox" style="display:none" <?= (isset($item['match_tmf']) && $item['match_tmf'] === 'Yes') ? 'checked' : '' ?> />
    <label class="toggle" for="<?= $math_id ?>">
        <span class="toggle__handler"></span>
    </label>-->
          <?php
$math_id = 'match_tmf_' . $index++;
?>
<input class="input match-toggle"
       data-field="match_tmf"
       data-id="<?= htmlspecialchars($item['pipeline_report_id'] ?? '') ?>"
       id="<?= $math_id ?>"
       type="checkbox"
       style="display:none"
       <?= (!empty($item['match_tmf']) && ($item['match_tmf'] == 1 || strtolower($item['match_tmf']) === 'yes')) ? 'checked' : '' ?> />
<label class="toggle" for="<?= $math_id ?>">
    <span class="toggle__handler"></span>
</label>

       <?php } ?>
    </td>
    <td>
    <?php if(isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "New"){ ?>
    <?php }else if((isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "Completed")){ ?>
    <?php $ubo_id = 'ubo_' . $index++; ?>
    <input class="input match-toggle" data-field="ubo" data-id="<?= isset($item['pipeline_report_id']) ? htmlspecialchars($item['pipeline_report_id']) : '' ?>" id="<?= $ubo_id ?>" type="checkbox" style="display:none" <?= (isset($item['ubo']) && $item['ubo'] === 'Yes') ? 'checked' : '' ?> />
    <label class="toggle" for="<?= $ubo_id ?>">
        <span class="toggle__handler"></span>
             <?php }else{ ?>
                    <?php $ubo_id = 'ubo_' . $index++; ?>
    <input class="input match-toggle" data-field="ubo" data-id="<?= isset($item['pipeline_report_id']) ? htmlspecialchars($item['pipeline_report_id']) : '' ?>" id="<?= $ubo_id ?>" type="checkbox" style="display:none" <?= (isset($item['ubo']) && $item['ubo'] === 'Yes') ? 'checked' : '' ?> />
    <label class="toggle" for="<?= $ubo_id ?>">
        <span class="toggle__handler"></span>
          <?php } ?>
    </label>
</td>
<td>
  <select class="form-control social-media-select" 
          data-id="<?= $item['pipeline_report_id'] ?? $item['id'] ?>" 
          style="height: 30px; width: 150px;">
      <option value="">Select</option>
      <option value="X" <?= ($item['social_media'] ?? '') == 'X' ? 'selected' : '' ?>>X</option>
      <option value="Instagram" <?= ($item['social_media'] ?? '') == 'Instagram' ? 'selected' : '' ?>>Instagram</option>
      <option value="TikTok" <?= ($item['social_media'] ?? '') == 'TikTok' ? 'selected' : '' ?>>TikTok</option>
      <option value="YouTube" <?= ($item['social_media'] ?? '') == 'YouTube' ? 'selected' : '' ?>>YouTube</option>
      <option value="LinkedIn" <?= ($item['social_media'] ?? '') == 'LinkedIn' ? 'selected' : '' ?>>LinkedIn</option>
      <option value="Facebook" <?= ($item['social_media'] ?? '') == 'Facebook' ? 'selected' : '' ?>>Facebook</option>
      <option value="Other" <?= ($item['social_media'] ?? '') == 'Other' ? 'selected' : '' ?>>Other</option>
  </select>
</td>

<td>   
<?php if ($pre_application_merchant_status == "true") { ?>  
<select
    style="height: 30px !important;width: 112px !important;"
    class="status-dropdown form-control"
    data-id="<?= $item['pipeline_report_id'] ?>"
    onchange="updateSelectColor(this)">
    <option value="Inactive" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Inactive') ? 'selected' : '' ?>>Inactive</option>
	<option value="PreAPP" <?= (isset($item['merchant_status_final']) && strcasecmp($item['merchant_status_final'], 'PreAPP') === 0) ? 'selected' : '' ?>>PreAPP</option>
    <option value="Onboarding" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Onboarding') ? 'selected' : '' ?>>Onboarding</option>
    <option value="Bank" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Bank') ? 'selected' : '' ?>>Bank</option>
    <option value="Management" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Management') ? 'selected' : '' ?>>Management</option>
    <option value="Approved" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Approved') ? 'selected' : '' ?>>Approved</option>
    <option value="Live" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Live') ? 'selected' : '' ?>>Live</option>
    <option value="Closed" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Closed') ? 'selected' : '' ?>>Closed</option>
      <option value="Declined" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Declined') ? 'selected' : '' ?>>Declined</option>
</select>
<?php } else { ?>
    <button
        class="btn btn-sm cancel-button <?= (isset($item['merchant_status']) && $item['merchant_status'] === 'Cancel') ? 'btn-danger' : 'btn-warning'; ?>"
        data-id="<?= $item['id']; ?>" data-status="<?= isset($item['merchant_status']) ? $item['merchant_status'] : ''; ?>">
        <?= (isset($item['merchant_status']) && $item['merchant_status'] === 'Cancel') ? 'Cancelled' : 'Cancel'; ?>
    </button>
<?php } ?>
</td>
    <td>
<?php if(isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "New"){ ?>



        <?php }else if((isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "Completed")){ ?>

        <a href="<?= admin_url('pipeline_report/copy/' . ($item['pipeline_report_id'] ?? '')) ?>" style="color:white" class="btn btn-sm btn-primary"><i class="fa fa-copy"></i> Copy </a>
      
       <?php }else{ ?>

        <a href="<?= admin_url('pipeline_report/copy/' . ($item['pipeline_report_id'] ?? '')) ?>" style="color:white" class="btn btn-sm btn-primary"><i class="fa fa-copy"></i> Copy </a>
        
        <?php } ?>
    </td>
    <td>
   <?php if(isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "New"){ ?>

        <a style="background:#90D5FF !important" href="<?php echo admin_url('pipeline_report/create/' . ($item['app_id'] ?? '')); ?>" class="btn btn-sm btn-info">Manage</a>

      
       <?php }else{ ?>

        <a style="background:#90D5FF !important" href="<?php echo admin_url('pipeline_report/view/' . ($item['pipeline_report_id'] ?? '')); ?>" class="btn btn-sm btn-info">Manage</a>

        
        <?php } ?>
    </td>
<td style="text-align:center !important">
    <?php if (!empty($item['is_duplicate'])): ?>
        <button class="btn btn-sm bg-danger view-duplicates"
                data-key="<?= strtolower(trim($item['final_email'])) . '|' . trim($item['final_phone']) . '|' . strtolower(trim($item['final_bank_name'])) ?>">
            Duplication Alerts
        </button>
    <?php endif; ?>
</td>
     <td>
<a style="background:#6c757d !important;color: white;" 
   href="<?= admin_url('pipeline_report/download_pdf/' . ($item['pipeline_report_id'] ?? '')) ?>" 
   class="btn btn-sm btn-secondary" target="_blank">
   <i class="fa fa-file-pdf-o"></i> Download
</a>


     </td>

    <td>
         <?php if(isset($item['pipeline_report_id'])){ ?>
        <a href="<?= admin_url('pipeline_report/activity_log/' . ($item['pipeline_report_id'] ?? '')) ?>" 
        class="btn btn-sm btn-secondary">
        <i class="fa fa-history me-1"></i> Log
        </a>
          <?php } ?>

    </td>
<td class="<?= (!is_admin()) ? 'd-none' : '' ?>">
        <?php if (is_admin()): ?>
            <button class="btn btn-sm btn-danger delete-record"
                    data-id="<?= $record_id ?>"
                    data-type="<?= $record_status ?>"
                    data-status="<?= $record_status ?>">
                <i class="fa fa-trash"></i> Delete
            </button>
        <?php endif; ?>
              </td>
    <td class="<?= (!is_admin()) ? 'd-none' : '' ?>">
        <?php if (is_admin()): ?>
            <button class="btn btn-sm btn-secondary archive-record"
                    data-id="<?= $record_id ?>"
                    data-status="<?= $record_status ?>">
                <i class="fa fa-archive"></i> Archive
            </button>
        <?php endif; ?>
    </td>

    <td>
        <select style="height:30px !important"
                class="status-dropdown form-control"
                data-id="<?= $record_id ?>"
                data-status="<?= $record_status ?>">
            <option value="Yes" <?= ($item['pipeline_cancel_status'] ?? '') == 'Yes' ? 'selected' : '' ?>>Yes</option>
            <option value="No" <?= ($item['pipeline_cancel_status'] ?? '') == 'No' ? 'selected' : '' ?>>No</option>
        </select>
    </td>
    <td>
    <?= htmlspecialchars($item['application_source'] ?? '') ?>
</td>

    </tr>
        <?php endforeach; ?>
    </tbody>
              </table>
            </div><!-- /.table-wrapper -->
     <?php if (!empty($combined_list)): 
    // rows per page (keep in sync with controller)
    $per_page = 20;

    // current page and row counts (fallbacks if not present)
    $current_page = isset($pagination['current_page']) ? (int)$pagination['current_page'] : 1;
    $rows_this_page = count($combined_list);

    // start and end for the current page
    $start = ($current_page - 1) * $per_page + 1;
    $end = $start + $rows_this_page - 1;

    // Use server-provided total_rows when possible (recommended)
    if (isset($pagination['total_rows'])) {
        $total_rows = (int)$pagination['total_rows'];
    } elseif (isset($total_rows)) {
        // controller might have passed total_rows separately
        $total_rows = (int)$total_rows;
    } else {
        // fallback: estimate from total_pages if present
        $total_rows = isset($pagination['total_pages']) ? ($pagination['total_pages'] * $per_page) : $rows_this_page;
    }
?>
<p class="text-muted mb-1 pipeline-showing">
    Showing <?= $start ?>–<?= $end ?> of <?= $total_rows ?> rows
</p>
<?php endif; ?>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Duplicate Details Modal -->
<div class="modal fade" id="duplicateModal" tabindex="-1" role="dialog" aria-labelledby="duplicateModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="text-danger"><i class="fa fa-exclamation-triangle mr-2"></i>Duplicate Applications Detected</h5>
        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="duplicateModalBody">
        Loading...
      </div>
    </div>
  </div>
</div>

<!-- Delete Confirmation Modal 
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h4 class="modal-title" id="deleteModalLabel">Confirm Deletion</h4>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="deleteReason">Reason for deletion:</label>
                    <textarea class="form-control" id="deleteReason" rows="3" required></textarea>
                </div>
                <input type="hidden" id="deleteRecordId">
                <input type="hidden" id="deleteRecordType">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Delete</button>
            </div>
        </div>
    </div>
</div>-->

<!-- Cancel Confirmation Modal -->

<div class="modal fade" id="cancelModal" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      
      <div class="modal-header">
        <h5 class="modal-title" id="cancelModalTitle">Cancel Application</h5>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      
      <div class="modal-body">
        <input type="hidden" id="cancel_id">
        
        <div id="cancelInfoSection" style="display:none;">
          <p><strong>Cancelled By:</strong> <span id="cancelled_by"></span></p>
          <p><strong>Cancelled At:</strong> <span id="cancelled_at"></span></p>
        </div>
        
        <div class="form-group">
          <label for="cancel_reason">Reason for Cancel</label>
          <textarea id="cancel_reason" class="form-control" required></textarea>
        </div>
      </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-danger" id="cancelSubmitBtn" onclick="submitCancel()">Cancel</button>
      </div>
      
    </div>
  </div>
</div>

<?php init_tail(); ?>
 
<script>
// ✅ Handle social media dropdown change
$(document).on('change', '.social-media-select', function() {
    var id = $(this).data('id');
    var platform = $(this).val();

    $.ajax({
        url: admin_url + 'pipeline_report/update_social_media',
        type: 'POST',
        dataType: 'json',
        data: { id: id, platform: platform },
        success: function(response) {
            if (response.success) {
                alert_float('success', 'Social media updated successfully');
            } else {
                alert_float('danger', 'Failed to update social media');
            }
        },
        error: function() {
            alert_float('danger', 'Server error while updating social media');
        }
    });
});




  
document.addEventListener("DOMContentLoaded", function() {
  const tableWrapper = document.querySelector('.table-wrapper');
  const scrollbarTop = document.querySelector('.scrollbar-top');
  const table = document.querySelector('#pipelineTable');

  // Adjust top scrollbar width
  function adjustScrollbar() {
    scrollbarTop.firstElementChild.style.width = table.scrollWidth + 'px';
  }
  adjustScrollbar();

  // Sync scroll
  tableWrapper.addEventListener('scroll', () => {
    scrollbarTop.scrollLeft = tableWrapper.scrollLeft;
  });
  scrollbarTop.addEventListener('scroll', () => {
    tableWrapper.scrollLeft = scrollbarTop.scrollLeft;
  });

  window.addEventListener('resize', adjustScrollbar);

  // Status dropdown colors
  function updateSelectColor(select) {
    select.className = 'status-dropdown form-control';
    switch(select.value.toLowerCase()){
      case 'inactive': select.classList.add('inactive'); break;
      case 'preapp': select.classList.add('preapp'); break;
      case 'onboarding': select.classList.add('onboarding'); break;
      case 'bank': select.classList.add('bank'); break;
      case 'management': select.classList.add('management'); break;
      case 'approved': select.classList.add('approved'); break;
      case 'live': select.classList.add('live'); break;
      case 'closed': select.classList.add('closed'); break;
      case 'declined': select.classList.add('declined'); break;
    }
  }

  document.querySelectorAll('.status-dropdown').forEach(function(sel){
    updateSelectColor(sel);
    sel.addEventListener('change', () => updateSelectColor(sel));
  });
});
</script>

<script>
const combinedList = <?= json_encode($combined_list ?? []); ?>;
</script>
<script>

var admin_url = '<?= admin_url(); ?>';

function openCancelModal(id) {
    $('#cancelModalTitle').text("Cancel Application");
    $('#cancel_id').val(id);
    $('#cancel_reason').val('').prop('readonly', false);
    $('#cancelInfoSection').hide();
    $('#cancelSubmitBtn').show();
    $('#cancelModal').modal('show');
}

function viewCancelDetails(id) {
    $.ajax({
        url: admin_url + "pipeline_report/get_cancel_details",
        type: "POST",
        dataType: "json",
        data: { id: id },
        success: function (response) {
            if (response.success) {
                $('#cancelModalTitle').text("Cancelled Information");
                $('#cancel_id').val(id);
                $('#cancel_reason').val(response.data.cancel_reason).prop('readonly', true);
                $('#cancelled_by').text(response.data.cancelled_by_name);
                $('#cancelled_at').text(response.data.cancelled_at);
                $('#cancelInfoSection').show();
                $('#cancelSubmitBtn').hide();
                $('#cancelModal').modal('show');
            } else {
                alert(response.message);
            }
        },
        error: function () {
            alert("Something went wrong while fetching cancel details.");
        }
    });
}

function submitCancel() {
    var id = $('#cancel_id').val();
    var reason = $('#cancel_reason').val();

    if (reason.trim() === '') {
        alert("Please enter a reason for cancellation.");
        return;
    }

    $.ajax({
        url: admin_url + "pipeline_report/cancel_record",
        type: "POST",
        dataType: "json",
        data: { id: id, reason: reason },
        success: function (response) {
            if (response.success) {
                //alert(response.message);

                // Dynamically update the button to badge
                var cancelBtn = $('button[onclick="openCancelModal(' + id + ')"]');
                if (cancelBtn.length) {
                    //cancelBtn.replaceWith('<span class="badge badge-danger cursor-pointer" onclick="viewCancelDetails(' + id + ')">Cancelled</span>');
                  cancelBtn.replaceWith('<span style="background-color:#dc3545;color:white;cursor:pointer;padding:3px 8px;border-radius:4px;" onclick="viewCancelDetails(' + id + ')">Cancelled</span>');

                }

                $('#cancelModal').modal('hide');
            } else {
                alert(response.message);
            }
        },
        error: function () {
            alert("Something went wrong. Please try again.");
        }
    });
}
  
  $(document).on('click', '.delete-record', function() {
    var recordId = $(this).data('id');
    var recordType = $(this).data('type');
    
    $('#deleteRecordId').val(recordId);
    $('#deleteRecordType').val(recordType);
    $('#deleteReason').val('');
    $('#deleteModal').modal('show');
});


  
  
// -------------- End of Duplication Alert -------------- //  


$('.view-duplicates').click(function(){
    const key = $(this).data('key');
    console.log("Clicked key:", key);

    const matched = combinedList.filter(row => {
        const email = (row.final_email ?? '').toLowerCase().trim();
        const phone = (row.final_phone ?? '').trim();
        const bank  = (row.final_bank_name ?? '').toLowerCase().trim();
        const rowKey = email + '|' + phone + '|' + bank;

        console.log("Comparing with rowKey:", rowKey);

        return rowKey === key;
    });

    console.log("Matched count:", matched.length);

    let html = `
      <div class="table-responsive">
        <table class="table table-striped table-hover table-bordered align-middle">
          <thead class="thead-dark">
            <tr>
              <th>Email</th>
              <th>Mobile Number</th>
              <th>Bank Name</th>
              <th>Application ID</th>
            </tr>
          </thead>
          <tbody>`;

    matched.forEach(row => {
        html += `
          <tr>
            <td><span class="badge badge-secondary">${row.final_email ?? '-'}</span></td>
            <td>${row.final_phone ?? '-'}</td>
            <td>${row.final_bank_name ?? '-'}</td>
            <td><strong>${row.pipeline_report_id ?? row.app_id ?? '-'}</strong></td>
          </tr>`;
    });

    html += `
          </tbody>
        </table>
      </div>
    `;

    $('#duplicateModalBody').html(html);
    $('#duplicateModal').modal('show');
});


// -------------- End of Duplication Alert -------------- //


$(document).ready(function () {
  
    // Select/Deselect all
    $('#select_all').on('change', function () {

        $('.client_checkbox').prop('checked', this.checked);
    });

    // Uncheck 'Select All' if any checkbox is unchecked manually
    $(document).on('change', '.client_checkbox', function () {
        if (!this.checked) {
            $('#select_all').prop('checked', false);
        }

        // If all checkboxes are checked, check 'Select All'
        if ($('.client_checkbox:checked').length === $('.client_checkbox').length) {
            $('#select_all').prop('checked', true);
        }
    });

    // Delete Selected
    $('#delete_selected').on('click', function () {
        var selectedIds = $('.client_checkbox:checked').map(function () {
            return $(this).val();
        }).get();

        if (selectedIds.length === 0) {
            alert('Please select at least one record.');
            return;
        }

        if (confirm('Are you sure you want to delete the selected records?')) {
            $.ajax({
                url: '<?= admin_url('pipeline_report/delete_multiple'); ?>',
                type: 'POST',
                data: { ids: selectedIds },
                dataType: 'json',
                success: function (response) {
                    console.log(response);
                    if (response.success) {
                        alert(response.message);
                        location.reload();
                    } else {
                        alert('Error: ' + response.message);
                    }
                },
                error: function () {
                    alert('An unexpected error occurred.');
                }
            });
        }
    });


      // Apply color on page load
    $('.status-dropdown').each(function () {
        updateStatusColor($(this), $(this).val());
    });
	
  

  function updateStatusColor(selectElement, status) {
        selectElement.removeClass('preapp onboarding underwriting bank management inactive approved live closed');

        switch (status.toLowerCase()) {
            case 'inactive':
                selectElement.addClass('inactive');
                break;
            case 'preapp':
                selectElement.addClass('preapp');
                break;
            case 'onboarding':
                selectElement.addClass('onboarding');
                break;
            case 'underwriting':
                selectElement.addClass('underwriting');
                break;
            case 'bank':
                selectElement.addClass('bank');
                break;         
            case 'management':
                selectElement.addClass('management');
                break;
            case 'approved':
                selectElement.addClass('approved');
                break;
            case 'live':
                selectElement.addClass('live');
                break;
            case 'closed':
                selectElement.addClass('closed');
                break;
        }
    }



    $(document).on('change', '.status-dropdown', function () {
        var $this = $(this); // Correctly define $this here
        updateStatusColor($this, $this.val());
        var $dropdown = $(this);
        var newStatus = $dropdown.val();
        var id = $dropdown.data('id');

        var $wrapper = $dropdown.closest('.status-wrapper');

        $.ajax({
            type: "POST",
            url: admin_url + "pipeline_report/update_status",
            data: { id: id, status: newStatus },
            success: function (response) {
                var data = JSON.parse(response);
                if (data.success) {
                    // Update wrapper color
                    $wrapper
                        .removeClass('bg-success bg-danger bg-secondary')
                        .addClass(getStatusClass(newStatus));
                } else {
                    alert('Failed to update status.');
                }
            },
            error: function () {
                alert('Server error while updating status.');
            }
        });
    });
});

$(document).on('change', '.match-toggle', function () {
    const field = $(this).data('field'); // match_tmf or ubo
    const id = $(this).data('id');       // record ID
    const value = $(this).is(':checked') ? 'Yes' : 'No';

    $.ajax({
        url: "<?= admin_url('pipeline_report/update_toggle') ?>",
        type: "POST",
        data: {
            id: id,
            field: field,
            value: value
        },
        success: function (response) {
            console.log('Updated successfully:', response);
        },
        error: function () {
            alert('Failed to update. Please try again.');
        }
    });
});
function updateSelectColor(selectElement) {
    if (!selectElement || !selectElement.classList) return; // safety

    // Remove all status classes
    selectElement.classList.remove(
        'preapp','onboarding','underwriting','bank','declined',
        'management','inactive', 'approved', 'live', 'closed'
    );

    // Add class based on selected value
    const status = selectElement.value?.toLowerCase(); // like "approved"
    if (status) {
        selectElement.classList.add(status);
    }
}


// On page load, initialize all status-dropdowns with the right color
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".status-dropdown").forEach(function (el) {
        updateSelectColor(el);
    });
});

$(document).on('change', '.status-dropdown', function () {
    var $dropdown = $(this);
    updateSelectColor(this); // safe call here

    var newStatus = $dropdown.val();
    var id = $dropdown.data('id');

    $.ajax({
        type: "POST",
        url: admin_url + "pipeline_report/update_status",
        data: { id: id, status: newStatus },
        success: function (response) {
            var data = JSON.parse(response);
            if (data.success) {
                // Optionally apply color class again
                updateSelectColor($dropdown[0]);
            } else {
                alert('Failed to update status.');
            }
        },
        error: function () {
            alert('Server error while updating status.');
        }
    });
});

    
<?php $rolevalue = $this->roles_model->get($current_user->role);
if (isset($rolevalue->name) && ($rolevalue->name == "agent" || $rolevalue->name == "reseller" || $rolevalue->name == "partner admin")) {  ?>
    // Disable Right-Click

  document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
  });

  // Disable Keyboard Shortcuts (like F12, Ctrl+Shift+I, Ctrl+U)
  document.onkeydown = function(e) {
    if (
      e.keyCode === 123 || // F12
      (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I or Ctrl+Shift+J
      (e.ctrlKey && e.keyCode === 85) // Ctrl+U
    ) {
      return false;
    }
  };
   <?php } ?>
  


</script>
<script>
$(document).ready(function () {

  // ✅ Filter by Status (Improved)
  $('#statusFilter').on('change', function () {
    const selectedStatus = $(this).val().toLowerCase().trim();

    $('#pipelineTable tbody tr').each(function () {
      const $row = $(this);

      // find the "main" merchant status select in this row (ignore cancel ones)
      const $statusSelect = $row.find('select.status-dropdown')
                                .not('[data-field], [data-cancel]')
                                .first();

      const currentStatus = ($statusSelect.find('option:selected').text() || '').toLowerCase().trim();

      if (selectedStatus === '' || selectedStatus === 'all') {
        $row.show(); // show all if All selected
      } else if (currentStatus === selectedStatus) {
        $row.show();
      } else {
        $row.hide();
      }
    });
  });

});

</script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(document).ready(function() {

  // Handle Cancel Yes/No select
  $(document).on('change', '.status-dropdown[data-id]', function() {
      const dropdown = $(this);
      const pipelineId = dropdown.data('id');
      const selectedValue = dropdown.val();

      // Ask for confirmation before updating
      Swal.fire({
          title: 'Are you sure?',
          text: "Do you want to change Cancel status to '" + selectedValue + "'?",
          icon: 'question',
          showCancelButton: true,
          confirmButtonText: 'Yes, update it!',
          cancelButtonText: 'No, keep it'
      }).then((result) => {
          if (result.isConfirmed) {
              // Proceed with AJAX update
              $.ajax({
                  url: admin_url + 'pipeline_report/update_cancel_status',
                  type: 'POST',
                  data: {
                      id: pipelineId,
                      status: selectedValue
                  },
                  dataType: 'json',
                  success: function(response) {
                      if (response.success) {
                          Swal.fire({
                              icon: 'success',
                              title: 'Updated!',
                              text: 'Cancel status has been updated successfully.',
                              timer: 1500,
                              showConfirmButton: false
                          });
                      } else {
                          Swal.fire('Error', 'Unable to update status. Try again.', 'error');
                      }
                  },
                  error: function() {
                      Swal.fire('Error', 'AJAX request failed. Check console.', 'error');
                      console.error('AJAX failed for cancel update');
                  }
              });
          } else {
              // Revert to old value if cancelled
              dropdown.val(dropdown.data('previous'));
          }
      });
  });

  // Store previous value to restore if cancelled
  $(document).on('focus', '.status-dropdown[data-id]', function() {
      $(this).data('previous', $(this).val());
  });

});
</script>
<script>
$(document).ready(function() {
// $(document).on('click', '.delete-record', function(e) {
       
//         e.preventDefault();
//         var button = $(this);
//         var id = button.data('id');
//         var type = button.data('type');
//         var status = button.data('status');
//         var reason = prompt("Enter reason for deleting this record:");
//         if (reason === null) return;

//         $.ajax({
//             url: admin_url + 'pipeline_report/delete_record',
//             type: 'POST',
//             data: {
//                 id: id,
//                 type: type,
//                 status: status,
//                 reason: reason
//             },
//             dataType: 'json',
//             success: function(response) {
//                 if (response.success) {
//                     alert_float('success', response.message);
//                     $('#pipelineTable').DataTable().ajax.reload();
//                 } else {
//                     alert_float('danger', response.message);
//                 }
//             },
//             error: function() {
//                 alert_float('danger', 'Error deleting record.');
//             }
//         });
//     });
  
  	$('.delete-record').on('click', function() {
    var id = $(this).data('id');
    var type = $(this).data('type');
    var reason = prompt('Enter reason for deletion:');
    if (reason) {
        $.post(admin_url + 'pipeline_report/delete_record', { id: id, type: type, reason: reason }, function(resp) {
            var res = JSON.parse(resp);
            alert(res.message);
            if (res.success) location.reload();
        });
    }
});


   
    $(document).on('click', '.archive-record', function(e) {
        e.preventDefault();
        var button = $(this);
        var id = button.data('id');
        var status = button.data('status');
        if (!confirm('Are you sure you want to archive this record?')) return;

        $.ajax({
            url: admin_url + 'pipeline_report/archive_record',
            type: 'POST',
            data: {
                id: id,
                status: status
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert_float('success', response.message);
                    $('#pipelineTable').DataTable().ajax.reload();
                } else {
                    alert_float('danger', response.message);
                }
            },
            error: function() {
                alert_float('danger', 'Error archiving record.');
            }
        });
    });
});
</script>
<script>
document.addEventListener("DOMContentLoaded", function() {
  const table = document.getElementById("pipelineTable");
  const tbody = table.querySelector("tbody");
  const searchInput = document.getElementById("tableSearch");
  const statusFilter = document.getElementById("statusFilter");

  // Make headers sortable
  const headers = table.querySelectorAll("thead th");
  const sortState = Array(headers.length).fill(null); // null / 'asc' / 'desc'
  headers.forEach((th, idx) => {
    // Prevent making the last few action columns sortable (e.g. buttons)
    // You can add/remove indexes as needed. Here we skip if cell contains button/icon
    if (th.querySelector('a, button, .fa, .btn')) {
      return;
    }
    th.classList.add('sortable');
    const indicator = document.createElement('span');
    indicator.className = 'sort-indicator';
    th.appendChild(indicator);

    th.addEventListener('click', () => {
      const current = sortState[idx];
      const next = current === 'asc' ? 'desc' : 'asc';
      sortState.fill(null);
      sortState[idx] = next;
      headers.forEach((h,i) => {
        const ind = h.querySelector('.sort-indicator');
        if(!ind) return;
        ind.textContent = sortState[i] === 'asc' ? '▲' : (sortState[i] === 'desc' ? '▼' : '');
      });
      sortTableByColumn(idx, next === 'asc');
    });
  });

  function parseCellValue(text) {
    if (!text) return '';
    const trimmed = text.trim();
    // Try number
    const num = trimmed.replace(/[^0-9\.\-]/g, '');
    if (num !== '' && !isNaN(num)) return parseFloat(num);
    // Try date (basic ISO or common formats)
    const date = Date.parse(trimmed);
    if (!isNaN(date)) return date;
    // fallback string
    return trimmed.toLowerCase();
  }

  function sortTableByColumn(colIndex, asc = true) {
    const rows = Array.from(tbody.querySelectorAll('tr'));
    rows.sort((a, b) => {
      const aText = (a.children[colIndex] && a.children[colIndex].innerText) ? a.children[colIndex].innerText : '';
      const bText = (b.children[colIndex] && b.children[colIndex].innerText) ? b.children[colIndex].innerText : '';
      const A = parseCellValue(aText);
      const B = parseCellValue(bText);
      if (A === B) return 0;
      if (typeof A === 'number' && typeof B === 'number') return asc ? A - B : B - A;
      if (typeof A === 'number' || typeof B === 'number') return asc ? (isNaN(A) ? 1 : -1) : (isNaN(B) ? -1 : 1);
      return asc ? (A > B ? 1 : -1) : (A > B ? -1 : 1);
    });
    rows.forEach(r => tbody.appendChild(r));
    updateShowingText();
  }

  // Live search: filters by search input and status filter
  function filterRows() {
    const term = (searchInput.value || '').trim().toLowerCase();
    const statusVal = (statusFilter.value || '').toLowerCase();
    const rows = tbody.querySelectorAll('tr');

    rows.forEach(row => {
      let text = row.innerText.toLowerCase();
      // If status filter is selected, ensure row's Status column contains it
      let statusMatch = true;
      if (statusVal) {
        // find Status cell text — attempt to find header index for 'Status'
        const statusIndex = findHeaderIndexByText('status');
        if (statusIndex !== -1) {
          const statusCell = row.children[statusIndex];
          const statusText = statusCell ? statusCell.innerText.toLowerCase() : '';
          statusMatch = statusText.includes(statusVal);
        }
      }
      const searchMatch = term === '' || text.includes(term);
      row.style.display = (statusMatch && searchMatch) ? '' : 'none';
    });

    updateShowingText();
  }

  // utility to find header index by header text (case-insensitive)
  function findHeaderIndexByText(txt) {
    for (let i = 0; i < headers.length; i++) {
      if (headers[i].innerText.trim().toLowerCase().startsWith(txt.toLowerCase())) return i;
    }
    return -1;
  }

  // update "Showing X–Y of Z rows" — uses server-provided total_rows if available
  function updateShowingText() {
    // look for the paragraph element we used below (class="pipeline-showing")
    let p = document.querySelector('.pipeline-showing');
    if (!p) return;
    const visibleRows = Array.from(tbody.querySelectorAll('tr')).filter(r => r.style.display !== 'none');
    const allRowsCount = tbody.querySelectorAll('tr').length;
    // If server gives total rows in a data attribute on the table (recommended),
    // e.g. <table id="pipelineTable" data-total-rows="<?= $total_rows ?>">
    const totalRowsAttr = parseInt(table.getAttribute('data-total-rows')) || allRowsCount;
    // If you are using server pagination show rows for current page:
    const start = visibleRows.length ? ( (<?php echo (int)($pagination['current_page'] ?? 1); ?> - 1) * <?php echo (int)(20); ?> + 1 ) : 0;
    const end = start + visibleRows.length - 1;
    p.innerText = `Showing ${start}–${end} of ${totalRowsAttr} rows`;
  }

  // event listeners
  searchInput.addEventListener('input', filterRows);
  statusFilter.addEventListener('change', filterRows);

  // Initial update (and call once to populate showing text)
  updateShowingText();

  // If your table data changes async, call updateShowingText() afterwards
});
</script>


