<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<style>
.status-dropdown {
    color: white;
    font-weight: bold;
    border: none;
    padding: 5px 5px;
    border-radius: 4px;
    width: 100px;
}

.status-dropdown.pending {
    background-color: #ffc107; /* yellow */
}

.status-dropdown.approved {
    background-color: #28a745; /* green */
}

.status-dropdown.declined {
    background-color: #dc3545; /* red */
}

</style>
<div id="wrapper">
    <div class="content">
        <div class="row">
            <div class="col-md-12">
            <h4 class="tw-my-0 tw-font-bold tw-text-xl">ISO/Reseller Applications</h4>
            <hr>
                <div class="panel_s">
                    <div class="panel-body">

                    <hr>
                        <table class="table dt-table table-striped">
                        <thead>
                            <tr>
                                <!-- <th><input type="checkbox" id="select_all"></th>  -->
                                    <th class="text-left">Application ID</th>
                                    <th class="text-left">Applicant Name</th>
                                    <th class="text-left">Email ID</th>
                                    <th class="text-left">Created At</th>
                                    <th class="text-left">Status</th>
                                    <th class="text-left">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($reseller_lists as $reseller_list): ?>
             
        
            <tr>
            <!-- <td><input type="checkbox" class="client_checkbox" value="<?= $reseller_list['reseller_id']; ?>"></td> -->
            <td class="text-left"><?php echo $reseller_list['reseller_code']; ?></td>
                <td class="text-left"><?php echo $reseller_list['first_name'] . ' ' . $reseller_list['last_name']; ?></td>
                <td class="text-left"><?php echo $reseller_list['email']; ?></td>
                <td class="text-left"><?php echo $reseller_list['created_at']; ?></td>
                <td >    
                <select style="height: 30px !important"  class="status-dropdown form-control" data-id="<?= $reseller_list['reseller_id'] ?>">
                <option value="Pending" <?= $reseller_list['status'] == 'Pending' ? 'selected' : '' ?>>Pending</option>
                <option value="Approved" <?= $reseller_list['status'] == 'Approved' ? 'selected' : '' ?>>Approved</option>
                <option value="Declined" <?= $reseller_list['status'] == 'Declined' ? 'selected' : '' ?>>Declined</option>
                </select>
                </td>
                <td class="text-left"><a style="background:#90D5FF !important" href="<?php echo admin_url('reseller/reseller_view/' . $reseller_list['reseller_id']); ?>" class="btn btn-sm btn-info">View</a></td>
               
              </tr>
            <?php endforeach; ?>
                            </tbody>
                        </table>
                   
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php init_tail(); ?>
<script>
$(document).ready(function () {
    // Select/Deselect All Logic
    $('#select_all').on('change', function () {
        $('.client_checkbox').prop('checked', this.checked);
    });

    $(document).on('change', '.client_checkbox', function () {
        $('#select_all').prop('checked', $('.client_checkbox:checked').length === $('.client_checkbox').length);
    });

    // Delete Selected
    $('#delete_selected').on('click', function () {
        var selectedIds = $('.client_checkbox:checked').map(function () {
            return $(this).val();
        }).get();

        if (selectedIds.length === 0) {
            alert('Please select at least one record.');
            return;
        }

        if (confirm('Are you sure you want to delete the selected records?')) {
            var csrfName = "<?= $this->security->get_csrf_token_name(); ?>";
            var csrfHash = "<?= $this->security->get_csrf_hash(); ?>";

            $.ajax({
                url: '<?= admin_url('reseller/delete_multiple'); ?>',
                type: 'POST',
                data: {
                    ids: selectedIds,
                    [csrfName]: csrfHash
                },
                dataType: 'json',
                success: function (response) {
                    alert(response.message);
                    if (response.success) location.reload();
                },
                error: function (xhr) {
                    alert('Unexpected error: ' + xhr.responseText);
                }
            });
        }
    });

    // Status Dropdown Color and Update
    function updateStatusColor(selectElement, status) {
        selectElement.removeClass('pending approved declined');
        selectElement.addClass(status.toLowerCase());
    }

    $('.status-dropdown').each(function () {
        updateStatusColor($(this), $(this).val());
    }).on('change', function () {
        const $this = $(this);
        const id = $this.data('id');
        const status = $this.val();
        updateStatusColor($this, status);

        $.ajax({
            type: "POST",
           url: "<?= admin_url('reseller/update_resellers_status'); ?>",
            data: { id: id, status: status },
            success: function (data) {
                console.log('Status update response:', data);
            },
            error: function (xhr, status, error) {
                console.error('AJAX error:', error);
            }
        });
    });

    <?php   $rolevalue = $this->roles_model->get($current_user->role); if (in_array($rolevalue->name, ['agent', 'reseller', 'partner admin'])) { ?>
        document.addEventListener('contextmenu', function (e) {
            e.preventDefault();
        });
        document.onkeydown = function (e) {
            if (
                e.keyCode === 123 || // F12
                (e.ctrlKey && e.shiftKey && [73, 74].includes(e.keyCode)) || // Ctrl+Shift+I/J
                (e.ctrlKey && e.keyCode === 85) // Ctrl+U
            ) return false;
        };
    <?php } ?>
});


</script>



