<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<style>
.sidebar-theme-switcher {
    margin: 18px 14px 10px;
    padding: 14px;
    border-radius: 18px;
    background: rgba(255,255,255,0.15);
    border: 1px solid rgba(255,255,255,0.25);
    box-shadow: 0 8px 24px rgba(0,0,0,0.12);
}

.theme-title {
    font-size: 12px;
    font-weight: 700;
    color: rgba(255,255,255,0.85);
    margin-bottom: 12px;
    text-align: center;
    letter-spacing: .4px;
}

.theme-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 9px;
    justify-items: center;
}

.theme-btn {
    width: 31px;
    height: 31px;
    border-radius: 50%;
    border: 2px solid rgba(255,255,255,0.55);
    cursor: pointer;
    transition: all .25s ease;
    box-shadow: 0 4px 12px rgba(0,0,0,.22);
}

.theme-btn:hover {
    transform: scale(1.16);
}

.theme-btn.active-theme {
    border: 3px solid #fff;
    box-shadow: 0 0 0 3px rgba(255,255,255,.25), 0 6px 18px rgba(0,0,0,.35);
}

.theme-reset-btn {
    width: 100%;
    margin-top: 13px;
    padding: 8px 10px;
    border-radius: 999px;
    border: none;
    background: #fff;
    color: #00468B;
    font-weight: 700;
    font-size: 12px;
    transition: .25s ease;
}

.theme-reset-btn:hover {
    background: #f1f5f9;
    transform: translateY(-1px);
}
        /* Only style the Bankcard Management section */
.menu-item-admin > a {
    background-color: #00468B !important;
    
}

/* Style its dropdown menu */
#bankcardMenu {
    background-color: #00468B !important;
}

/* Ensure submenu items are visible */
#bankcardMenu li a {
    color: white !important;
}
/* Main Navigation Background */


/* Dropdown Arrows (if they are icons) */
.fa-arrow {
    color: white !important;
}
/* Sidebar container */
.sidebar {
    display: flex;
    flex-direction: column;
    height: 100%;
  	
}

/* Navigation items */
.sidebar {
    flex: 1 1 auto; /* takes up remaining space */
}

/* Logo container */
.sidebar-logo {
    flex-shrink: 0; /* stays at bottom, never shrinks */
    padding: 20px 50px;
    text-align: center;
 
}
.sidebar-logo img {
    max-width: 120px;
}

</style>
    <aside id="menu" class="sidebar">
        <?php $isSidebarDark = function_exists('is_admin_sidebar_background_light') ?
                is_admin_sidebar_background_light() :
                false; ?>
        <div class="dropdown sidebar-user-profile tw-mt-[80px] tw-mx-1.5 ">
            <a href="#"
                class="dropdown-toggle profile -tw-mt-1 tw-font-medium tw-border tw-border-solid tw-rounded-lg tw-bg-white/20 tw-py-2 tw-px-2.5 tw-block tw-shadow-sm <?= $isSidebarDark ? 'tw-text-white tw-border-white/10 hover:tw-border-white/30 focus:tw-border-white/30 hover:tw-text-white focus:tw-text-white hover:tw-bg-neutral-900/10 focus:tw-bg-neutral-900/10' : 'tw-border-neutral-900/20 tw-text-neutral-700 hover:tw-text-neutral-800 focus:tw-text-neutral-800 hover:tw-bg-neutral-900/5 focus:tw-bg-neutral-900/5'; ?>"
                data-toggle="dropdown" aria-expanded="false">
                <span class="tw-inline-flex tw-items-center tw-gap-x-3 tw-pt-0.5">
                    <?= staff_profile_image($current_user->staffid, ['img', 'img-responsive', 'staff-profile-image-small']); ?>
                    <span>
                        <span
                            class="tw-truncate tw-block tw-w-[140px] tw-font-semibold"><?= get_staff_full_name(); ?></span>
                      <span
                            class="tw-truncate tw-block tw-w-[140px] tw-font-semibold"><?php if (!empty(get_staff()->agent_id)) : ?>RID: <?= get_staff()->agent_id; ?><?php endif; ?></span>
                        <span
                            class="tw-font-normal tw-truncate tw-block tw-w-[140px] tw-text-sm <?= $isSidebarDark ? 'tw-text-neutral-300' : 'tw-text-neutral-500' ?>">
                            <?= get_staff()->email; ?>
                        </span>
                    </span>
                </span>
            </a>
            <ul class="dropdown-menu tw-w-full">
                        <?php 
                $is_agent = !empty(get_staff()->agent_id); // or check role if you store it
                ?>

                                <li class="header-my-profile">
                    <a href="<?= $is_agent ? site_url('reseller/profile') : admin_url('profile'); ?>">
                        <?= _l('nav_my_profile'); ?>
                    </a>
                </li>

                <li class="header-my-timesheets">
                  <a href="<?= $is_agent ? base_url('reseller/profile/timesheets') : admin_url('staff/timesheets'); ?>">
                      <?= _l('my_timesheets'); ?>
                  </a>
                </li>


                <li class="header-edit-profile">
                    <a href="<?= $is_agent ? base_url('reseller/profile/edit_profile') : admin_url('staff/edit_profile'); ?>">
                        <?= _l('nav_edit_profile'); ?>
                    </a>
                </li>
                <?php if (! is_language_disabled()) { ?>
                <li class="dropdown-submenu pull-left header-languages">
                    <a href="#"
                        tabindex="-1"><?= _l('language'); ?></a>
                    <ul class="dropdown-menu dropdown-menu">
                        <li
                            class="<?= $current_user->default_language == '' ? 'active' : ''; ?>">
                            <a
                                href="<?= admin_url('staff/change_language'); ?>">
                                <?= _l('system_default_string'); ?>
                            </a>
                        </li>
                        <?php foreach ($this->app->get_available_languages() as $user_lang) { ?>
                        <li
                            class="<?= $current_user->default_language == $user_lang ? 'active' : ''; ?>">
                            <a
                                href="<?= admin_url('staff/change_language/' . $user_lang); ?>">
                                <?= e(ucfirst($user_lang)); ?>
                            </a>
                            <?php } ?>
                    </ul>
                </li>
                <?php } ?>
                <li class="header-logout">
                    <a href="#"
                        onclick="logout(); return false;"><?= _l('nav_logout'); ?></a>
                </li>
            </ul>
        </div>
        <?php $rolevalue = $this->roles_model->get($current_user->role);
        $CI =& get_instance();
        $current_user = $CI->staff_model->get(get_staff_user_id());
        $role = $CI->roles_model->get($current_user->role ?? 0);

        $current_role = strtolower(trim($role->name ?? ''));
        $login_context = $CI->session->userdata('login_context') ?? '';

        $bankcard_only_roles = [
            'agent',
            'reseller',
            'partner admin',
            'relationship management team',
            'management',
        ];

// Show only your custom sidebar when:
// 1. user role is in allowed list
// OR
// 2. admin logged in through your special authentication context
$show_bankcard_only_sidebar = in_array($current_role, $bankcard_only_roles) || $login_context === 'reseller';
 if ($show_bankcard_only_sidebar): 
?>

        <ul class="nav metis-menu tw-mt-[15px]" id="side-menu">

        <li class="menu-item-res-dashboard">
              <a href="<?= site_url('admin/dashboard'); ?>" aria-expanded="false">
                <i class="fa-regular fa-object-group menu-icon"></i>
                <span class="menu-text">Dashboard</span>
            </a>
        </li>
            <li class="menu-item-res-pipeline">
                <a href="<?= site_url('admin/pipeline_report'); ?>" aria-expanded="false">
                <i class="fa fa-cogs fa-2x fa-object-group menu-icon"></i>
                    <span class="menu-text">Application</span>
                    <span class="fa arrow pleft5"></span>
                </a>
                
            <ul class="nav nav-second-level collapse" aria-expanded="false">
                    <li class="sub-menu-item-custom1">
                        <a href="<?php echo site_url('admin/pipeline_report/create'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">Add Buisness Merchant Oppurtunity</span>
                        </a>
                    </li>
                    <li class="sub-menu-item-custom1">
                        <a href="<?php echo site_url('admin/pipeline_report'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">Pipeline Summary Report</span>
                        </a>
                    </li>
              

            </ul>
            </li>
                                <?php 
$rolevalue = $this->roles_model->get($current_user->role); 
$is_agent = isset($rolevalue->name) && $rolevalue->name == 'agent';
?>
            <li class="menu-item-res-reseller">
            <a href="<?= site_url('admin/agents'); ?>" aria-expanded="<?= $current_segment == 'reseller' ? 'true' : 'false'; ?>">
                    <i class="fa fa-store fa-2x fa-object-group menu-icon"></i>
                    <span class="menu-text">Resellers & ISO <br>&nbsp;&nbsp;&nbsp;&nbsp;Management</span>
                    <span class="fa arrow pleft5"></span>
                </a>
                
            <ul class="nav nav-second-level collapse" aria-expanded="false">
               <?php if (!$is_agent) { ?>
                    <li class="sub-menu-item-custom1">
                    <a href="<?php echo admin_url('reseller/integrate'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">ISO/Reseller Office</span>
                        </a>
                    </li>
                     <?php if (isset($rolevalue->name) && $rolevalue->name != "reseller" && $rolevalue->name != "agent") { ?> 
                    <li class="sub-menu-item-custom4">
                        <a href="<?= admin_url('reseller'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">ISO Applications List</span>
                        </a>
                    </li>
                     <?php } ?>
              
                    <li class="sub-menu-item-custom2">
                    <a href="<?php echo admin_url('reseller/create'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">Setup ISO Application</span>
                        </a>
                    </li>
                    <li class="sub-menu-item-custom4">
                        <a href="<?= admin_url('reseller/reseller_list'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">Reseller List</span>
                        </a>
                    </li>
                    <li class="menu-item-res-portfolio">
            <a href="<?= admin_url('agents/create'); ?>" aria-expanded="false">
                <span class="menu-text">Sub - Agent Resellers</span>
                    <span class="fa arrow pleft5"></span>
                </a>
                
            <ul class="nav nav-second-level collapse" aria-expanded="false">
                    <li class="sub-menu-item-custom1">
                        <a href="<?php echo admin_url('agents/create'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">Sub - Agent Reseller Application</span>
                        </a>
                    </li>
                    <li class="sub-menu-item-custom1">
                        <a href="<?php echo admin_url('agents'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">Sub - Agent Reseller List</span>
                        </a>
                    </li>
                 
            </ul>
            </li> 
              
                 <?php } ?>
              	 <?php if ($is_agent) { ?>
              
                            <li class="menu-item-res-portfolio">
            <a href="<?= site_url('admin/agents/create'); ?>" aria-expanded="false">
                <span class="menu-text">Sub - Agent Resellers</span>
                    <span class="fa arrow pleft5"></span>
                </a>
                
            <ul class="nav nav-second-level collapse" aria-expanded="false">
                    <li class="sub-menu-item-custom1">
                        <a href="<?php echo site_url('reseller/agents/create'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">Sub - Agent Reseller Application</span>
                        </a>
                    </li>
                    <li class="sub-menu-item-custom1">
                        <a href="<?php echo site_url('admin/agents'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">Sub - Agent Reseller List</span>
                        </a>
                    </li>
                 
            </ul>
            </li> 
            <?php } ?>
            </ul>
            </li> 

            <!--<li class="menu-item-res-portfolio">
            <a href="<?= site_url('reseller/pre_application'); ?>" aria-expanded="false">
                <i class="fas fa-credit-card fa-object-group menu-icon"></i>
                <span class="menu-text">Merchant</span>
                    <span class="fa arrow pleft5"></span>
            </a>
                
            <ul class="nav nav-second-level collapse" aria-expanded="false">
                    <li class="sub-menu-item-custom1">
                        <a href="<?php echo site_url('reseller/pre_application/create'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">Merchant Pre Application</span>
                        </a>
                    </li>
                    <li class="sub-menu-item-custom1">
                        <a href="<?php echo site_url('reseller/pre_application'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">Application List</span>
                        </a>
                    </li>
                    <li class="sub-menu-item-custom1">
                        <a href="<?= site_url('reseller/pre_application/pre_application_detail'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">Merchants</span>
                        </a>
                    </li>
            </ul>
            </li>-->   
            
            <li class="menu-item-res-portfolio">
                <a href="#" aria-expanded="false">
                    <i class="fas fa-briefcase menu-icon"></i>
                    <span class="menu-text">Portfolio</span>
                    <span class="fa arrow pleft5"></span>
                </a>
                
            <ul class="nav nav-second-level collapse" aria-expanded="false">
                    <li class="sub-menu-item-custom1">
                        <a href="<?php echo site_url('admin/coming_soon/us_banks'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">US Banks</span>
                        </a>
                    </li>
                    <li class="sub-menu-item-custom1">
                        <a href="<?php echo site_url('admin/coming_soon/international_banks'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">International Banks</span>
                        </a>
                    </li>
            </ul>
            </li>  
          <li class="menu-item-res-portfolio">
          <a href="<?php echo admin_url('logo_settings');  ?>">
                <i class="fas fa-chart-line fa-object-group menu-icon"></i>
                <span class="menu-text">Logo Settings</span>
                </a>
  		 </li>  
        

            <li class="menu-item-res-residuals">
                <a href="<?= site_url('admin/coming_soon/residuals'); ?>" aria-expanded="false">
                <i class="fas fa-coins fa-object-group menu-icon"></i>
                <span class="menu-text">Residuals</span>
                </a>
            </li>   
            <li class="menu-item-res-pricing">
                <a href="<?= site_url('admin/coming_soon/pricing'); ?>" aria-expanded="false">
                <i class="fas fa-dollar-sign fa-object-group menu-icon"></i>
                <span class="menu-text">Pricing</span>
                </a>
            </li>         
            <li class="menu-item-res-resource">
                <a href="<?= site_url('admin/coming_soon/resource_marketing'); ?>" aria-expanded="false">
                <i class="fas fa-chart-line fa-object-group menu-icon"></i>
                <span class="menu-text">Resource & Marketing</span>
                </a>
            </li>
            <li class="menu-item-res-resource">
                <a href="<?= site_url('admin/coming_soon/iso_ai_support'); ?>" aria-expanded="false">
                <i class="fas fa-door-open  menu-icon"></i>
                <span class="menu-text">ISO AI Support</span>
                </a>
            </li>
            <li class="menu-item-res-notes">
                <a href="<?= site_url('admin/coming_soon/notes'); ?>" aria-expanded="false">
                <i class="fa fa-sticky-note fa-object-group menu-icon"></i>
                <span class="menu-text">Notes</span>
                </a>
            </li>
            <li class="menu-item-res-equipment">
                <a href="<?= site_url('admin/coming_soon/equipment'); ?>" aria-expanded="false">
                <i class="fa fa-wrench fa-object-group menu-icon"></i>
                <span class="menu-text">Equipment</span>
                </a>
            </li>   
            <!--<li class="menu-item-res-users">
                <a href="<?= admin_url('users'); ?>" aria-expanded="false">
                <i class="fas fa-users menu-icon"></i>
                <span class="menu-text">Users</span>
                </a>
            </li>-->
    
            <!--<li class="menu-item-res-application">
                <a href="<?= admin_url('coming_soon/pre_application'); ?>" aria-expanded="false">
                <i class="fa-paper-plane fa-object-group menu-icon"></i>
                <span class="menu-text">Pre-Application</span>
                <span class="fa arrow pleft5"></span>
                </a>
                <ul class="nav nav-second-level collapse" aria-expanded="false">
                    <li class="sub-menu-item-custom1">
                        <a href="<?php echo admin_url('pre_application/create'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">New Pre-Application</span>
                        </a>
                    </li>
                    <li class="sub-menu-item-custom1">
                        <a href="<?php echo admin_url('pre_application'); ?>">
                            <i class="fa fa-circle-o menu-icon"></i>
                            <span class="sub-menu-text">View Pre-Application</span>
                        </a>
                    </li>

            </ul>
            </li>-->
            <li class="menu-item-res-support">
                <a href="<?= site_url('admin/coming_soon/support_tickets'); ?>" aria-expanded="false">
                <i class="fa fa-ticket fa-object-group menu-icon"></i>
                <span class="menu-text">Support Tickets</span>
                </a>
            </li>
            <li class="menu-item-res-funding">
                <a href="<?= site_url('admin/coming_soon/funding'); ?>" aria-expanded="false">
                <i class="fas fa-money-check-alt menu-icon"></i>
                <span class="menu-text">Funding & Holds</span>
                </a>
            </li>
            <li class="menu-item-res-statements">
                <a href="<?= site_url('admin/coming_soon/statements'); ?>" aria-expanded="false">
                <i class="fa fa-book fa-object-group menu-icon"></i>
                <span class="menu-text">Statements</span>
                </a>
            </li>  
            <li class="menu-item-res-risk">
                <a href="<?= site_url('admin/coming_soon/risk_management'); ?>" aria-expanded="false">
                <i class="fas fa-bug fa-object-group menu-icon"></i>
                <span class="menu-text">Risk Management</span>
                </a>
            </li>
                                <li class="menu-item-res-risk">
                <a href="<?= site_url('reseller/disclaimer'); ?>" aria-expanded="false">
                   <i class="fa fa-ticket fa-object-group menu-icon"></i>
                    <span class="menu-text">Disclaimer</span>
                </a>
            </li>
        </ul>
<?php else: ?>
          
<?php endif; ?>

          
<div class="sidebar-logo text-center">
 <?php
        $custom_logo = get_option('admin_logo_custom');

        if (!empty($custom_logo)) {
            $logo = base_url($custom_logo) . '?v=' . time();
        } else {
            $logo = get_user_company_logo() . '?v=' . time();
        }
    ?>

    <?php if (empty($logo)) { ?>
        <a class="logo logo-text tw-text-2xl tw-font-semibold"
            href="<?= hooks()->apply_filters('admin_header_logo_href', admin_url()); ?>">
            <?= e(get_option('companyname')); ?>
        </a>
    <?php } else { ?>
        <a class="logo"
            href="<?= hooks()->apply_filters('admin_header_logo_href', admin_url()); ?>">
            <img src="<?= e($logo); ?>"
                class="img-responsive"
                alt="<?= e(get_option('companyname')); ?>" />
        </a>
    <?php } ?>
</div>
 <div class="sidebar-theme-switcher">
    <div class="theme-title">Navigation Themes</div>

    <div class="theme-grid">
        <button class="theme-btn" data-color="#90D5FF" title="Original Sky Blue" style="background:#90D5FF;"></button>
        <button class="theme-btn" data-color="#FFD6A6" title="Pink" style="background:#FFD6A6;"></button>
        <button class="theme-btn" data-color="#9AD872" title="Green" style="background:#9AD872;"></button>
        <button class="theme-btn" data-color="#FFFBA7" title="Yellow" style="background:#FFFBA7;"></button>
        <button class="theme-btn" data-color="#F6F4E8" title="Grey" style="background:#F6F4E8;"></button>
        <button class="theme-btn" data-color="#B7A3E3" title="Purple" style="background:#B7A3E3;"></button>
        <button class="theme-btn" data-color="#FF937E" title="Red" style="background:#FF937E;"></button>
        <button class="theme-btn" data-color="#C1D8C3" title="Graphite" style="background:#C1D8C3;"></button>
        <button class="theme-btn" data-color="#DEAC80" title="Cyan" style="background:#DEAC80;"></button>
        <button class="theme-btn" data-color="#DEF9C4" title="Blue" style="background:#DEF9C4;"></button>
        <button class="theme-btn" data-color="#FCC6FF" title="Violet" style="background:#FCC6FF;"></button>
        <button class="theme-btn" data-color="#B5C0D0" title="Orange" style="background:#B5C0D0;"></button>
    </div>

    <button type="button" class="theme-reset-btn" id="reset-sidebar-theme">
        Reset Original
    </button>
</div>
    </aside>
<script>
window.addEventListener('load', function () {
    if (typeof jQuery === 'undefined') return;

    var $ = jQuery;
    var originalColor = '#90D5FF';
    var savedColor = localStorage.getItem('sidebarThemeColor') || originalColor;

    applySidebarTheme(savedColor);

    $(document).on('click', '.theme-btn', function () {
        var color = $(this).data('color');
        localStorage.setItem('sidebarThemeColor', color);
        applySidebarTheme(color);
    });

    $(document).on('click', '#reset-sidebar-theme', function () {
        localStorage.setItem('sidebarThemeColor', originalColor);
        applySidebarTheme(originalColor);
    });

    function applySidebarTheme(color) {
        $('.sidebar, #menu, #side-menu, .nav-second-level, .nav-third-level, .nav-fourth-level').css({
            'background': color
        });

        // Sidebar menu text - Perfex style dark text for light sidebar
        $('.sidebar #side-menu a, .sidebar #side-menu .menu-text, .sidebar #side-menu .sub-menu-text, .sidebar #side-menu .menu-icon, .sidebar #side-menu .fa').css({
            'color': '#2d3f50'
        });

        // Active menu
        $('.sidebar #side-menu li.active > a').css({
            'background': '#ffffff',
            'color': '#00468B',
            'border-radius': '10px',
            'font-weight': '700'
        });

        $('.sidebar #side-menu li.active > a .menu-text, .sidebar #side-menu li.active > a .menu-icon, .sidebar #side-menu li.active > a .fa').css({
            'color': '#00468B'
        });

        // Profile dropdown should stay normal Perfex style
        $('.sidebar-user-profile .dropdown-menu').css({
            'background': '#ffffff',
            'border-radius': '10px',
            'padding': '10px 0',
            'box-shadow': '0 10px 25px rgba(0,0,0,0.18)'
        });

        $('.sidebar-user-profile .dropdown-menu a').css({
            'color': '#111827',
            'font-weight': '500',
            'padding': '12px 24px',
            'display': 'block',
            'background': '#ffffff'
        });

        $('.sidebar-user-profile .dropdown-menu a:hover').css({
            'background': '#f3f4f6',
            'color': '#00468B'
        });

        // Keep profile card readable
        $('.sidebar-user-profile .profile, .sidebar-user-profile .profile span').css({
            'color': '#2d3f50'
        });

        $('.theme-btn').removeClass('active-theme');
        $('.theme-btn[data-color="' + color + '"]').addClass('active-theme');
    }
});
</script>