<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<?php init_head(); ?>
<style>

.table-responsive {
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}
.table-responsive-wrapper table {
    min-width: 1200px !important;
    font-size: 12px !important;  
}  

.status-dropdown {
    color: white;
    font-weight: bold;
    border: none;
    padding: 5px 5px;
    border-radius: 4px;
    width: 100px;
}


.status-dropdown.inactive {
    background-color: grey; /* yellow */
}
.status-dropdown.preapp {
    background-color: grey; /* yellow */
}
.status-dropdown.onboarding {
    background-color: grey; /* red */
}
.status-dropdown.underwriting {
    background-color: grey; /* yellow */
}
.status-dropdown.bank {
    background-color: grey; /* yellow */
}
.status-dropdown.management {
    background-color: grey; /* red */
}
.status-dropdown.live {
    background-color: #008000; /* red */
}
.status-dropdown.approved {
    background-color: #008000; /* yellow */
}

.status-dropdown.closed {
    background-color: #dc3545; /* red */
}


/* I am not the orginal creator */
.toggleWrapper {
    /*position: absolute;
    /* top: 50%;
    padding: 0px 164px; 
    left: 86%;*/

    overflow: hidden;
    /* transform: translate3d(-50%, -50%, 0); */
    color: white;
}

.toggleWrapper .input {
  position: absolute;
  left: -99em;
}

.toggle {
  cursor: pointer;
  display: inline-block;
  position: relative;
  width: 65px;
  height: 25px;
  background-color: red;
  border-radius: 84px;
 
}

.toggle:before {
  content: "Yes";
  position: absolute;
  left: 7px;
  top: 3px;
  font-size: 13px;
  color: red;
}

.toggle:after {
  content: "No";
  position: absolute;
  right: 7px;
  top: 3px;
  font-size: 13px;
  color: white;
}

.toggle__handler {
  display: inline-block;
  position: relative;
  z-index: 1;
  top: 3px;
  left: 3px;
  width: 20px;
  height: 20px;
  background-color: white;
  border-radius: 50px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
  transition: all 400ms cubic-bezier(0.68, -0.55, 0.265, 1.55);
  transform: rotate(-45deg);
}

.input:checked + .toggle {
  background-color: green;
}

.input:checked + .toggle:before {
  color: white;
}

.input:checked + .toggle:after {
  color: green;
}

.input:checked + .toggle .toggle__handler {
  background-color: white;
  transform: translate3d(40px, 0, 0) rotate(0);
}

.input:checked + .toggle .toggle__handler .crater {
  opacity: 1;
}


</style>
<div id="wrapper">
    <div class="content">
        <div class="row">
            <div class="col-md-12">
            <h4 class="tw-my-0 tw-font-bold tw-text-xl">Pipeline Report</h4>
            <hr>
                <div class="panel_s">
                    <div class="panel-body">
                    <a href="<?php echo admin_url('pipeline_report/create'); ?>" class="btn btn-primary">Add New Application</a>
                    <!--<button class="btn btn-danger" id="delete_selected">Delete </button>-->
                    <hr>
<div class="table-responsive" style="font-size:11px !important;">
    <table class="table table-striped table-bordered" id="pipelineTable">
                     
<thead>
    <tr>
        <th>Lead Source</th>
        <th>Company Name</th>
        <th>DBA Name</th>
        <th>Acquiring Location</th>  
        <th>Agent Name Contact</th>   
        <th>Owner</th>
        <th>Email</th>
        <th>Cell Phone Number</th>
        <th>Bank Name</th>
        <th>Date Recieved</th>
        <th>Match/TMF</th>
        <th>UBO</th>
        <th>Status</th>
        <th>Copy</th>
        <th>Manage</th>
        <th>Alerts</th>
        <th class="no-sort">Log</th>
    </tr>
</thead>

    <tbody>
        <?php $index = 1; foreach ($combined_list as $item): ?>
        <tr>

           
            <td><?= isset($item['lead_source']) ? htmlspecialchars($item['lead_source']) : ''; ?></td>
           <?php
            $business_name = isset($item['business_name']) ? $item['business_name'] : '';
            $company_name = isset($item['company_name']) ? $item['company_name'] : '';
            ?>
            <td><?= htmlspecialchars(!empty($business_name) ? $business_name : $company_name); ?></td>
            <?php
            $business_system = isset($item['business_system']) ? $item['business_system'] : '';
            $dba = isset($item['dba']) ? $item['dba'] : '';
            ?>
            <td><?= htmlspecialchars(!empty($business_system) ? $business_system : $dba); ?></td>
            <?php
            $business_country = isset($item['user_business_country']) ? $item['user_business_country'] : '';
            $pipeline_report_country = isset($item['pipeline_report_country']) ? $item['pipeline_report_country'] : '';
            ?>
            <td><?= htmlspecialchars(!empty($business_country) ? $business_country : $pipeline_report_country); ?></td>
            <?php
            $first_name = isset($item['staff_firstname']) ? $item['staff_firstname'] : '';
            $last_name = isset($item['staff_lastname']) ? $item['staff_lastname'] : '';
            $full_name = trim($first_name . ' ' . $last_name);
            ?>
            <td><?= htmlspecialchars(!empty($full_name) ? $full_name : $full_name); ?></td>
            <?php
            $first_name = isset($item['first_name']) ? $item['first_name'] : '';
            $last_name = isset($item['last_name']) ? $item['last_name'] : '';
            $contact_name = isset($item['contact_name']) ? $item['contact_name'] : '';
            $full_name = trim($first_name . ' ' . $last_name);
            ?>
            <td><?= htmlspecialchars(!empty($full_name) ? $full_name : $contact_name); ?></td>
            <?php
            $personal_email_address = isset($item['personal_email_address']) ? $item['personal_email_address'] : '';
            $email_address = isset($item['email_address']) ? $item['email_address'] : '';
            ?>
           <td><?= htmlspecialchars(!empty($personal_email_address) ? $personal_email_address : $email_address); ?></td>
            <?php
            $cell_number = isset($item['cell_number']) ? $item['cell_number'] : '';
            $contact_phone = isset($item['contact_phone']) ? $item['contact_phone'] : '';
            ?>
           <td><?= htmlspecialchars(!empty($cell_number) ? $cell_number : $contact_phone); ?></td>
            <?php
            $bank_name = isset($item['pipeline_bank']) ? $item['pipeline_bank'] : '';
            $pipeline_report_bank_name = isset($item['pipeline_report_bank_name']) ? $item['pipeline_report_bank_name'] : '';
            ?>
           <td><?= htmlspecialchars(!empty($bank_name) ? $bank_name : $pipeline_report_bank_name); ?></td>
          
            <?php
            $date_received = isset($item['date_received']) ? $item['date_received'] : '';
            $application_date = isset($item['application_date']) ? $item['application_date'] : '';
            ?>
           <td><?= htmlspecialchars(!empty($date_received) ? $date_received : $application_date); ?></td>

<td>

<?php if(isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "New"){ ?>



        <?php }else if((isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "Completed")){ ?>
    <?php $math_id = 'match_tmf_' . $index++; ?>
    <input class="input match-toggle" data-field="match_tmf" data-id="<?= isset($item['pipeline_report_id']) ? htmlspecialchars($item['pipeline_report_id']) : '' ?>" id="<?= $math_id ?>" type="checkbox" style="display:none" <?= (isset($item['match_tmf']) && $item['match_tmf'] === 'Yes') ? 'checked' : '' ?> />
    <label class="toggle" for="<?= $math_id ?>">
        <span class="toggle__handler"></span>
    </label>
         <?php }else{ ?>
    <?php $math_id = 'match_tmf_' . $index++; ?>
    <input class="input match-toggle" data-field="match_tmf" data-id="<?= isset($item['pipeline_report_id']) ? htmlspecialchars($item['pipeline_report_id']) : '' ?>" id="<?= $math_id ?>" type="checkbox" style="display:none" <?= (isset($item['match_tmf']) && $item['match_tmf'] === 'Yes') ? 'checked' : '' ?> />
    <label class="toggle" for="<?= $math_id ?>">
        <span class="toggle__handler"></span>
    </label>
       <?php } ?>

</td>
<td>
<?php if(isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "New"){ ?>



        <?php }else if((isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "Completed")){ ?>
    <?php $ubo_id = 'ubo_' . $index++; ?>
    <input class="input match-toggle" data-field="ubo" data-id="<?= isset($item['pipeline_report_id']) ? htmlspecialchars($item['pipeline_report_id']) : '' ?>" id="<?= $ubo_id ?>" type="checkbox" style="display:none" <?= (isset($item['ubo']) && $item['ubo'] === 'Yes') ? 'checked' : '' ?> />
    <label class="toggle" for="<?= $ubo_id ?>">
        <span class="toggle__handler"></span>
             <?php }else{ ?>
                    <?php $ubo_id = 'ubo_' . $index++; ?>
    <input class="input match-toggle" data-field="ubo" data-id="<?= isset($item['pipeline_report_id']) ? htmlspecialchars($item['pipeline_report_id']) : '' ?>" id="<?= $ubo_id ?>" type="checkbox" style="display:none" <?= (isset($item['ubo']) && $item['ubo'] === 'Yes') ? 'checked' : '' ?> />
    <label class="toggle" for="<?= $ubo_id ?>">
        <span class="toggle__handler"></span>
          <?php } ?>
    </label>
</td>

<td>   
<?php if ($pre_application_merchant_status == "true") { ?>  
<select
    style="height: 30px !important;width: 112px !important;"
    class="status-dropdown form-control"
    data-id="<?= $item['pipeline_report_id'] ?>"
    onchange="updateSelectColor(this)">
    <option value="Inactive" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Inactive') ? 'selected' : '' ?>>Inactive</option>
	<option value="PreAPP" <?= (isset($item['merchant_status_final']) && strcasecmp($item['merchant_status_final'], 'PreAPP') === 0) ? 'selected' : '' ?>>PreAPP</option>
    <option value="Onboarding" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Onboarding') ? 'selected' : '' ?>>Onboarding</option>
    <option value="Bank" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Bank') ? 'selected' : '' ?>>Bank</option>
    <option value="Management" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Management') ? 'selected' : '' ?>>Management</option>
    <option value="Approved" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Approved') ? 'selected' : '' ?>>Approved</option>
    <option value="Live" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Live') ? 'selected' : '' ?>>Live</option>
    <option value="Closed" <?= (isset($item['merchant_status_final']) && $item['merchant_status_final'] == 'Closed') ? 'selected' : '' ?>>Closed</option>
</select>
<?php } else { ?>
    <button
        class="btn btn-sm cancel-button <?= (isset($item['merchant_status']) && $item['merchant_status'] === 'Cancel') ? 'btn-danger' : 'btn-warning'; ?>"
        data-id="<?= $item['id']; ?>" data-status="<?= isset($item['merchant_status']) ? $item['merchant_status'] : ''; ?>">
        <?= (isset($item['merchant_status']) && $item['merchant_status'] === 'Cancel') ? 'Cancelled' : 'Cancel'; ?>
    </button>
<?php } ?>
</td>
    <td>
<?php if(isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "New"){ ?>



        <?php }else if((isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "Completed")){ ?>

        <a href="<?= admin_url('pipeline_report/copy/' . ($item['pipeline_report_id'] ?? '')) ?>" class="btn btn-sm btn-primary"><i class="fa fa-copy"></i> Copy </a>
      
       <?php }else{ ?>

        <a href="<?= admin_url('pipeline_report/copy/' . ($item['pipeline_report_id'] ?? '')) ?>" class="btn btn-sm btn-primary"><i class="fa fa-copy"></i> Copy </a>
        
        <?php } ?>
    </td>
    <td>
   <?php if(isset($item['merchant_pipeline_status']) && $item['merchant_pipeline_status'] == "New"){ ?>

        <a style="background:#90D5FF !important" href="<?php echo admin_url('pipeline_report/create/' . ($item['app_id'] ?? '')); ?>" class="btn btn-sm btn-info">Manage</a>

      
       <?php }else{ ?>

        <a style="background:#90D5FF !important" href="<?php echo admin_url('pipeline_report/view/' . ($item['pipeline_report_id'] ?? '')); ?>" class="btn btn-sm btn-info">Manage</a>

        
        <?php } ?>
    </td>

    <td style="text-align:center !important">
            <?php if (!empty($item['is_duplicate'])): ?>
            <button class="btn btn-sm bg-danger">Duplication Alerts</button>
            <?php else: ?>
            <?php endif; ?>
    </td>
    <td>
         <?php if(isset($item['pipeline_report_id'])){ ?>
        <a href="<?= admin_url('pipeline_report/activity_log/' . ($item['pipeline_report_id'] ?? '')) ?>" 
        class="btn btn-sm btn-secondary">
        <i class="fa fa-history me-1"></i> Log
        </a>
          <?php } ?>

    </td>

    </tr>
        <?php endforeach; ?>
    </tbody>
</table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php init_tail(); ?>


<script>
$(document).ready(function () {
  


    // Select/Deselect all
    $('#select_all').on('change', function () {

        $('.client_checkbox').prop('checked', this.checked);
    });

    // Uncheck 'Select All' if any checkbox is unchecked manually
    $(document).on('change', '.client_checkbox', function () {
        if (!this.checked) {
            $('#select_all').prop('checked', false);
        }

        // If all checkboxes are checked, check 'Select All'
        if ($('.client_checkbox:checked').length === $('.client_checkbox').length) {
            $('#select_all').prop('checked', true);
        }
    });

    // Delete Selected
    $('#delete_selected').on('click', function () {
        var selectedIds = $('.client_checkbox:checked').map(function () {
            return $(this).val();
        }).get();

        if (selectedIds.length === 0) {
            alert('Please select at least one record.');
            return;
        }

        if (confirm('Are you sure you want to delete the selected records?')) {
            $.ajax({
                url: '<?= admin_url('pipeline_report/delete_multiple'); ?>',
                type: 'POST',
                data: { ids: selectedIds },
                dataType: 'json',
                success: function (response) {
                    console.log(response);
                    if (response.success) {
                        alert(response.message);
                        location.reload();
                    } else {
                        alert('Error: ' + response.message);
                    }
                },
                error: function () {
                    alert('An unexpected error occurred.');
                }
            });
        }
    });


      // Apply color on page load
    $('.status-dropdown').each(function () {
        updateStatusColor($(this), $(this).val());
    });



    $(document).on('change', '.status-dropdown', function () {
        var $this = $(this); // Correctly define $this here
        updateStatusColor($this, $this.val());
        var $dropdown = $(this);
        var newStatus = $dropdown.val();
        var id = $dropdown.data('id');

        var $wrapper = $dropdown.closest('.status-wrapper');

        $.ajax({
            type: "POST",
            url: admin_url + "pipeline_report/update_status",
            data: { id: id, status: newStatus },
            success: function (response) {
                var data = JSON.parse(response);
                if (data.success) {
                    // Update wrapper color
                    $wrapper
                        .removeClass('bg-success bg-danger bg-secondary')
                        .addClass(getStatusClass(newStatus));
                } else {
                    alert('Failed to update status.');
                }
            },
            error: function () {
                alert('Server error while updating status.');
            }
        });
    });
});

  

  function updateStatusColor(selectElement, status) {
        selectElement.removeClass('preapp onboarding underwriting bank management inactive approved live closed');

        switch (status.toLowerCase()) {
            case 'inactive':
                selectElement.addClass('inactive');
                break;
            case 'preapp':
                selectElement.addClass('preapp');
                break;
            case 'onboarding':
                selectElement.addClass('onboarding');
                break;
            case 'underwriting':
                selectElement.addClass('underwriting');
                break;
            case 'bank':
                selectElement.addClass('bank');
                break;         
            case 'management':
                selectElement.addClass('management');
                break;
            case 'approved':
                selectElement.addClass('approved');
                break;
            case 'live':
                selectElement.addClass('live');
                break;
            case 'closed':
                selectElement.addClass('closed');
                break;
        }
    }

$(document).on('change', '.match-toggle', function () {
    const field = $(this).data('field'); // match_tmf or ubo
    const id = $(this).data('id');       // record ID
    const value = $(this).is(':checked') ? 'Yes' : 'No';

    $.ajax({
        url: "<?= admin_url('pipeline_report/update_toggle') ?>",
        type: "POST",
        data: {
            id: id,
            field: field,
            value: value
        },
        success: function (response) {
            console.log('Updated successfully:', response);
        },
        error: function () {
            alert('Failed to update. Please try again.');
        }
    });
});
function updateSelectColor(selectElement) {
    if (!selectElement || !selectElement.classList) return; // safety

    // Remove all status classes
    selectElement.classList.remove(
        'preapp','onboarding','underwriting','bank',
        'management','inactive', 'approved', 'live', 'closed'
    );

    // Add class based on selected value
    const status = selectElement.value?.toLowerCase(); // like "approved"
    if (status) {
        selectElement.classList.add(status);
    }
}


// On page load, initialize all status-dropdowns with the right color
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".status-dropdown").forEach(function (el) {
        updateSelectColor(el);
    });
});

$(document).on('change', '.status-dropdown', function () {
    var $dropdown = $(this);
    updateSelectColor(this); // safe call here

    var newStatus = $dropdown.val();
    var id = $dropdown.data('id');

    $.ajax({
        type: "POST",
        url: admin_url + "pipeline_report/update_status",
        data: { id: id, status: newStatus },
        success: function (response) {
            var data = JSON.parse(response);
            if (data.success) {
                // Optionally apply color class again
                updateSelectColor($dropdown[0]);
            } else {
                alert('Failed to update status.');
            }
        },
        error: function () {
            alert('Server error while updating status.');
        }
    });
});

    
<?php $rolevalue = $this->roles_model->get($current_user->role);
if (isset($rolevalue->name) && ($rolevalue->name == "agent" || $rolevalue->name == "reseller" || $rolevalue->name == "partner admin")) {  ?>
    // Disable Right-Click

  document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
  });

  // Disable Keyboard Shortcuts (like F12, Ctrl+Shift+I, Ctrl+U)
  document.onkeydown = function(e) {
    if (
      e.keyCode === 123 || // F12
      (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74)) || // Ctrl+Shift+I or Ctrl+Shift+J
      (e.ctrlKey && e.keyCode === 85) // Ctrl+U
    ) {
      return false;
    }
  };
   <?php } ?>

</script>


