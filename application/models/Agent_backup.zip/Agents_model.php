<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Agents_model extends App_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->db = $this->load->database('agent_crm', TRUE); // Connect to `agent_crm` database
    }

    /**
     * Insert pipeline report data into database
     */
    public function add_agents($data)
    {
        $this->db->insert('agents', $data);
        return $this->db->insert_id();
    }
  
  
  	    /**
     * Generate next application ID
     */
    public function get_next_application_id()
    {
        $row = $this->agent_db->select_max('id')->get('agents')->row();
        $nextId = ($row && $row->id) ? $row->id + 1 : 1;

        $offset   = 3660;
        $sequence = $nextId + $offset;

        $monthLetter = strtoupper(substr(date('F'), 0, 1));
        $yearTwo     = date('y');

        return $monthLetter . $yearTwo . str_pad($sequence, 4, '0', STR_PAD_LEFT);
    }

  
    public function get_last_agents_code()
    {
        $this->agent_db->select('agents_code');
        $this->agent_db->from('agents');
        $this->agent_db->like('agents_code', '360', 'after');
        $this->agent_db->order_by('id', 'DESC');
        $this->agent_db->limit(1);
        $query = $this->agent_db->get();
        $result = $query->row();

        return $result ? $result->agents_code : '360500';
    }

    /**
     * Insert pipeline report data into database
     */
    public function get_all_agents()
    {
        return $this->db->get('agents')->result_array();
    }

    public function get_agents_by_user_id($id)
    {
        $this->db->where('user_id', $id);
        return $this->db->get('agents')->result_array(); // Fetch single record
    }

    public function get_pipeline_report($id)
    {
        return $this->db->get_where('agents', ['id' => $id])->row_array();
    }

    public function get_agents_by_id($id)
    {
        $this->db->where('id', $id);
        return $this->db->get('agents')->row_array(); // Fetch single record
    }

    public function update_agents($id, $data)
    {
        $this->db->where('id', $id);
        return $this->db->update('agents', $data);
    }
    
    public function delete_multiple_agents($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('clients');
    }

    public function delete_agents($id)
    {
        $this->db->where('id', $id);
        return $this->db->delete('agents');
    }





}
